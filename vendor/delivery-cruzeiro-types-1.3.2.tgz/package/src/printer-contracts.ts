export type PrinterChannelTransport = 'WEB_SERIAL' | 'WINDOWS_BRIDGE';
export const PRINTER_RECEIPT_SECTIONS = ['customer', 'address', 'payment', 'notes', 'totals'] as const;
export type PrinterReceiptSection = (typeof PRINTER_RECEIPT_SECTIONS)[number];
export interface WindowsPrinterCapabilities {
	raw: boolean;
	color?: boolean;
	duplex?: boolean;
	paperSizes?: string[];
}
export interface WindowsPrinterDescriptor {
	queueId: string;
	name: string;
	driverName: string;
	portName?: string;
	printProcessor?: string;
	defaultDataType?: string;
	isDefault: boolean;
	status: 'READY' | 'OFFLINE' | 'ERROR' | 'UNKNOWN';
	capabilities: WindowsPrinterCapabilities;
}
export interface PrinterOperationalConfiguration {
	transport?: PrinterChannelTransport;
	windowsQueueId?: string | null;
	windowsQueueName?: string | null;
	windowsDriverName?: string | null;
	windowsPortName?: string | null;
	windowsPrintProcessor?: string | null;
	windowsDataType?: string | null;
	windowsCapabilities?: WindowsPrinterCapabilities | null;
	adapterId?: 'esc-pos' | 'daruma-dr700' | 'generic';
	columns?: number;
	encoding?: 'cp850' | 'latin1' | 'ascii';
	autoCut?: boolean;
	copies?: number;
	lastSeenAt?: string | null;
	lastKnownStatus?:
		| 'READY'
		| 'OFFLINE'
		| 'ERROR'
		| 'UNKNOWN'
		| 'MISSING'
		| 'CHANGED'
		| 'INCOMPATIBLE'
		| 'UNAVAILABLE'
		| null;
	bridgeInstallationId?: string | null;
}
