import { describe, expect, it } from 'vitest';
import {
	defaultStoreOperationSettings,
	isWithinStoreHours,
	isOperationOpen,
	isValidScheduledTime,
	storeOperationSettingsSchema,
} from './store-operation.js';

const settings = () => ({
	...defaultStoreOperationSettings,
	days: defaultStoreOperationSettings.days.map(day => ({ ...day })),
	hoursEnabled: true,
});
describe('store operation hours', () => {
	it('uses São Paulo time with inclusive opening and exclusive closing', () => {
		const s = settings();
		expect(isOperationOpen(s, new Date('2026-11-09T20:59:00Z'))).toBe(false);
		expect(isOperationOpen(s, new Date('2026-11-09T21:00:00Z'))).toBe(true);
		expect(isOperationOpen(s, new Date('2026-11-10T02:00:00Z'))).toBe(false);
	});
	it('keeps the previous day overnight interval open on a closed next day', () => {
		const s = settings();
		s.customHours = true;
		s.days[0] = { closed: false, open: '22:00', close: '02:00' };
		s.days[1] = { closed: true, open: null, close: null };
		expect(isWithinStoreHours(s, new Date('2026-11-10T04:00:00Z'))).toBe(true);
		expect(isWithinStoreHours(s, new Date('2026-11-10T05:00:00Z'))).toBe(false);
		expect(isWithinStoreHours(s, new Date('2026-11-11T04:00:00Z'))).toBe(false);
	});
	it('handles the Sunday/Monday boundary', () => {
		const s = settings();
		s.customHours = true;
		s.days[6] = { closed: false, open: '22:00', close: '02:00' };
		expect(isWithinStoreHours(s, new Date('2026-11-09T04:00:00Z'))).toBe(true);
	});
	it('manual status overrides the clock but scheduled times still respect hours', () => {
		const s = {
			...settings(),
			manualControl: true,
			manuallyOpen: false,
			acceptScheduled: true,
		};
		expect(isOperationOpen(s, new Date('2026-11-09T22:00:00Z'))).toBe(false);
		expect(
			isValidScheduledTime(s, '2026-11-09T22:00:00Z', new Date('2026-11-09T12:00:00Z'))
		).toBe(true);
		expect(
			isValidScheduledTime(s, '2026-11-09T13:00:00Z', new Date('2026-11-09T12:00:00Z'))
		).toBe(false);
	});
	it('ignores hours and manual closed status when the feature is off', () => {
		expect(
			isOperationOpen({
				...settings(),
				hoursEnabled: false,
				manualControl: true,
				manuallyOpen: false,
			})
		).toBe(true);
	});
	it('rejects past, invalid and disabled schedules', () => {
		const now = new Date('2026-11-09T12:00:00Z');
		const s = { ...settings(), acceptScheduled: true };
		for (const date of ['invalid', '2026-11-08T22:00:00Z'])
			expect(isValidScheduledTime(s, date, now)).toBe(false);
		expect(
			isValidScheduledTime({ ...s, acceptScheduled: false }, '2026-11-09T22:00:00Z', now)
		).toBe(false);
	});
	it('validates delay choices and requires hours for days that open', () => {
		expect(
			storeOperationSettingsSchema.safeParse({ ...settings(), acceptDelaySeconds: 3 }).success
		).toBe(false);
		const s = settings();
		s.customHours = true;
		s.days[0].open = null;
		expect(storeOperationSettingsSchema.safeParse(s).success).toBe(false);
		s.days[0].closed = true;
		expect(storeOperationSettingsSchema.safeParse(s).success).toBe(true);
	});
});
