import { describe, expect, it } from 'vitest';
import { adminOrderHistoryQuerySchema } from './index';

describe('order history query', () => {
  it('defaults to a bounded first page', () => {
    expect(adminOrderHistoryQuerySchema.parse({})).toEqual({ page: 1, pageSize: 10 });
  });
  it('accepts combined filters and coerces URL numbers', () => {
    expect(adminOrderHistoryQuerySchema.parse({ page: '2', pageSize: '30', orderNumber: '123', minTotal: '0', maxTotal: '90.50', startDate: '2026-10-01', endDate: '2026-10-31', customerName: ' Ana ', status: 'DELIVERED' }))
      .toMatchObject({ page: 2, pageSize: 30, orderNumber: 123, minTotal: 0, maxTotal: 90.5, customerName: 'Ana', status: 'DELIVERED' });
  });
  it.each([{ pageSize: 100 }, { pageSize: 0 }, { page: 0 }, { page: 1.5 }, { page: 'Infinity' }, { minTotal: -1 }, { orderNumber: 1.5 }, { startDate: '2026-02-30' }, { startDate: '2026-10-02', endDate: '2026-10-01' }, { minTotal: 50, maxTotal: 10 }, { status: 'UNKNOWN' }])('rejects invalid or unbounded queries %j', query => {
    expect(adminOrderHistoryQuerySchema.safeParse(query).success).toBe(false);
  });
});
