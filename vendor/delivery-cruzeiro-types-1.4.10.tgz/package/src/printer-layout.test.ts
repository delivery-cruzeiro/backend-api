import { describe, expect, it } from 'vitest';
import { printerReceiptLayoutSchema, resolvePrinterReceiptLayout } from './printer-layout.js';
import { setPrinterAssignmentsSchema, updatePrinterConfigurationSchema } from './index.js';

describe('printer receipt layout contract', () => {
  it('keeps partial updates free of formatting defaults', () => {
    expect(updatePrinterConfigurationSchema.parse({ name: 'Cozinha' })).toEqual({ name: 'Cozinha' });
    expect(setPrinterAssignmentsSchema.parse({}).receiptLayout).toBeUndefined();
  });
  it('preserves old routing and enables only the primary logo by default', () => {
    expect(resolvePrinterReceiptLayout({ categoryIds: ['food'], receiptSections: [] })).toMatchObject({ categoriesEnabled: true, orderDataEnabled: false, showLogo: false });
    expect(resolvePrinterReceiptLayout({ isPrimary: true })).toMatchObject({ showLogo: true, orderDataEnabled: true });
    expect(resolvePrinterReceiptLayout({})).toMatchObject({ categoriesEnabled: false, subcategoriesEnabled: false, orderDataEnabled: false });
  });
  it('rejects unsafe sizes, feeds and malformed individual formatting', () => {
    const layout = resolvePrinterReceiptLayout({});
    expect(printerReceiptLayoutSchema.safeParse({ ...layout, feedLines: 21 }).success).toBe(false);
    expect(printerReceiptLayoutSchema.safeParse({ ...layout, orderFields: { total: { enabled: true, bold: true, italic: false, fontSize: 900 } } }).success).toBe(false);
    expect(printerReceiptLayoutSchema.safeParse({ ...layout, feedLines: -1 }).success).toBe(false);
  });
});
