import { describe, expect, it } from 'vitest';
import { updateCategorySchema, updateProductSchema, updateSubcategorySchema } from './index.js';
describe('ordered image reference updates', () => {
	for (const [name, schema] of Object.entries({
		product: updateProductSchema,
		category: updateCategorySchema,
		subcategory: updateSubcategorySchema,
	})) {
		it(`${name} preserves omission, supports explicit removal and rejects invalid links`, () => {
			expect(schema.parse({ name: 'Updated' })).not.toHaveProperty('imageUrls');
			expect(schema.parse({ imageUrls: [] }).imageUrls).toEqual([]);
			expect(
				schema.parse({
					imageUrls: ['https://images.test/b.jpg', 'https://images.test/a.jpg'],
				}).imageUrls
			).toEqual(['https://images.test/b.jpg', 'https://images.test/a.jpg']);
			expect(schema.safeParse({ imageUrls: ['javascript:alert(1)'] }).success).toBe(false);
			expect(
				schema.safeParse({
					imageUrls: ['https://images.test/a.jpg', 'https://images.test/a.jpg'],
				}).success
			).toBe(false);
		});
	}
});
