import { z } from 'zod';

const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
const day = z.object({ closed: z.boolean(), open: time.nullable(), close: time.nullable() });
export const storeOperationSettingsSchema = z
	.object({
		autoAccept: z.boolean(),
		acceptDelaySeconds: z.union([z.literal(0), z.literal(2), z.literal(5), z.literal(10)]),
		hoursEnabled: z.boolean(),
		open: time,
		close: time,
		customHours: z.boolean(),
		manualControl: z.boolean(),
		manuallyOpen: z.boolean(),
		acceptScheduled: z.boolean(),
		days: z.array(day).length(7), // Monday = 0, Sunday = 6.
	})
	.superRefine((settings, context) => {
		if (settings.hoursEnabled && settings.customHours)
			settings.days.forEach((entry, index) => {
				if (!entry.closed && (!entry.open || !entry.close))
					context.addIssue({
						code: 'custom',
						path: ['days', index],
						message: 'Informe abertura e fechamento de cada dia de atendimento.',
					});
			});
	});
export type StoreOperationSettings = z.infer<typeof storeOperationSettingsSchema>;
export const defaultStoreOperationSettings: StoreOperationSettings = {
	autoAccept: false,
	acceptDelaySeconds: 0,
	hoursEnabled: false,
	open: '18:00',
	close: '23:00',
	customHours: false,
	manualControl: false,
	manuallyOpen: true,
	acceptScheduled: false,
	days: Array.from({ length: 7 }, () => ({ closed: false, open: '18:00', close: '23:00' })),
};
export const storeTimeZone = 'America/Sao_Paulo';
function localTime(date: Date) {
	const parts = new Intl.DateTimeFormat('en-CA', {
		timeZone: storeTimeZone,
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		hourCycle: 'h23',
	}).formatToParts(date);
	const get = (key: string) => parts.find(part => part.type === key)!.value;
	return {
		day:
			(new Date(`${get('year')}-${get('month')}-${get('day')}T12:00:00Z`).getUTCDay() + 6) %
			7,
		time: `${get('hour')}:${get('minute')}`,
	};
}
export function isWithinStoreHours(settings: StoreOperationSettings, date = new Date()): boolean {
	if (!settings.hoursEnabled) return true;
	const local = localTime(date);
	const entry = (index: number) =>
		settings.customHours
			? settings.days[index]
			: { closed: false, open: settings.open, close: settings.close };
	const today = entry(local.day),
		yesterday = entry((local.day + 6) % 7);
	// Overnight intervals belong to the day on which they start.
	const tail =
		!yesterday.closed &&
		yesterday.open &&
		yesterday.close &&
		yesterday.close < yesterday.open &&
		local.time < yesterday.close;
	if (tail) return true;
	if (today.closed || !today.open || !today.close) return false;
	if (today.open === today.close) return true; // 24 hours.
	return today.close > today.open
		? local.time >= today.open && local.time < today.close
		: local.time >= today.open;
}
export function isOperationOpen(settings: StoreOperationSettings, date = new Date()) {
	return (
		!settings.hoursEnabled ||
		(settings.manualControl ? settings.manuallyOpen : isWithinStoreHours(settings, date))
	);
}
export function isValidScheduledTime(
	settings: StoreOperationSettings,
	value: string,
	now = new Date()
) {
	const date = new Date(value);
	return (
		settings.hoursEnabled &&
		settings.acceptScheduled &&
		Number.isFinite(date.getTime()) &&
		date > now &&
		isWithinStoreHours(settings, date)
	);
}
export function describeStoreHours(settings: StoreOperationSettings) {
	if (!settings.hoursEnabled) return 'Atendimento sem restrição de horário';
	if (!settings.customHours)
		return `Atendimento: ${settings.open} às ${settings.close}${settings.close < settings.open ? ' do dia seguinte' : ''}`;
	const names = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];
	return settings.days
		.map(
			(day, index) =>
				`${names[index]}: ${day.closed ? 'fechado' : `${day.open} às ${day.close}${day.open && day.close && day.close < day.open ? ' do dia seguinte' : ''}`}`
		)
		.join(' · ');
}
