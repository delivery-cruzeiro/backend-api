import { describe, expect, it } from 'vitest';
import {
	UserRole,
	canAccessAdmin,
	hasRole,
	updateUserSchema,
	updateProductSchema,
	updateCategorySchema,
	updateSubcategorySchema,
} from './index.js';

describe('numeric user roles', () => {
	it('keeps the four names with their stable database values', () => {
		expect(UserRole).toEqual({ CLIENT: 1, ADMIN: 2, MANAGER: 3, SUPER_ADMIN: 4 });
	});

	it.each([undefined, null, 0, -1, 2.5, Infinity, '2', 'ADMIN', NaN])(
		'denies invalid role %s',
		role => {
			expect(canAccessAdmin(role)).toBe(false);
			expect(updateUserSchema.safeParse({ role }).success).toBe(role === undefined);
		}
	);

	it('inherits access from each minimum level, including future profiles', () => {
		for (const role of [...Object.values(UserRole), 5]) {
			expect(canAccessAdmin(role)).toBe(role !== UserRole.CLIENT);
			expect(hasRole(role, UserRole.ADMIN)).toBe(role >= 2);
			expect(hasRole(role, UserRole.MANAGER)).toBe(role >= 3);
			expect(hasRole(role, UserRole.SUPER_ADMIN)).toBe(role >= 4);
			expect(updateUserSchema.safeParse({ role }).success).toBe(true);
		}
	});

	it('preserves other catalog fields during status-only updates', () => {
		for (const schema of [updateProductSchema, updateCategorySchema, updateSubcategorySchema]) {
			expect(schema.parse({ isActive: false })).toEqual({ isActive: false });
		}
		expect(updateProductSchema.parse({ unavailable: true })).toEqual({ unavailable: true });
	});
});
