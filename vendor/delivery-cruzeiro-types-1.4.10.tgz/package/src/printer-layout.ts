import { z } from 'zod';

export const printerFieldStyleSchema = z.object({
  enabled: z.boolean(), bold: z.boolean(), italic: z.boolean(),
  fontSize: z.number().int().min(12).max(40),
});
const fields = z.record(z.string().min(1).max(400), printerFieldStyleSchema)
  .refine(value => Object.keys(value).length <= 150, 'Muitos campos de impressão');
const scopes = z.record(z.string().min(1).max(100), fields)
  .refine(value => Object.keys(value).length <= 1000, 'Muitas configurações de impressão');
export const printerReceiptLayoutSchema = z.object({
  version: z.literal(1), categoriesEnabled: z.boolean(), subcategoriesEnabled: z.boolean(),
  orderDataEnabled: z.boolean(), showLogo: z.boolean(),
  feedLines: z.number().int().min(0).max(20),
  categories: scopes, subcategories: scopes, orderFields: fields,
});
export type PrinterFieldStyle = z.infer<typeof printerFieldStyleSchema>;
export type PrinterReceiptLayout = z.infer<typeof printerReceiptLayoutSchema>;

export function defaultPrinterFieldStyle(key: string): PrinterFieldStyle {
  return { enabled: true, bold: ['productName', 'value', 'total'].includes(key),
    italic: false, fontSize: ['productName', 'value', 'total'].includes(key) ? 24 : 18 };
}

/** Read old printers without rewriting their persisted assignments. */
export function resolvePrinterReceiptLayout(printer: {
  isPrimary?: boolean; receiptLayout?: PrinterReceiptLayout | null;
  categoryIds?: string[]; subcategoryIds?: string[]; receiptSections?: readonly string[];
}): PrinterReceiptLayout {
  return printer.receiptLayout ?? {
    version: 1, categoriesEnabled: Boolean(printer.isPrimary || printer.categoryIds?.length),
    subcategoriesEnabled: Boolean(printer.isPrimary || printer.subcategoryIds?.length),
    orderDataEnabled: Boolean(printer.isPrimary || printer.receiptSections?.length),
    showLogo: Boolean(printer.isPrimary), feedLines: 3, categories: {}, subcategories: {}, orderFields: {},
  };
}
