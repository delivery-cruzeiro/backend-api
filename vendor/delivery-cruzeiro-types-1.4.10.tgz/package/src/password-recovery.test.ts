import { describe, expect, it } from 'vitest';
import { requestPasswordRecoverySchema, verifyPasswordRecoverySchema, resetRecoveredPasswordSchema } from './password-recovery.js';

describe('password recovery contracts', () => {
	it('normalizes email and rejects invalid addresses and extra fields', () => {
		expect(requestPasswordRecoverySchema.parse({ email: 'USER@example.com' }).email).toBe('user@example.com');
		expect(requestPasswordRecoverySchema.safeParse({ email: 'invalid' }).success).toBe(false);
		expect(requestPasswordRecoverySchema.safeParse({ email: 'a@b.com', userId: 'another-user' }).success).toBe(false);
	});
	it('requires exactly six digits, including leading zeros', () => {
		for (const code of ['12345', '1234567', '12a456', ' 123456']) {
			expect(verifyPasswordRecoverySchema.safeParse({ email: 'a@b.com', code }).success).toBe(false);
		}
		expect(verifyPasswordRecoverySchema.safeParse({ email: 'a@b.com', code: '000123' }).success).toBe(true);
	});
	it('requires a server authorization and matching passwords within the existing limits', () => {
		const data = { email: 'a@b.com', recoveryAuthorization: 'a'.repeat(64), password: 'new-pass123', confirmPassword: 'new-pass123' };
		expect(resetRecoveredPasswordSchema.safeParse(data).success).toBe(true);
		for (const changes of [{ confirmPassword: 'different' }, { recoveryAuthorization: '123456' }, { password: 'short', confirmPassword: 'short' }]) {
			expect(resetRecoveredPasswordSchema.safeParse({ ...data, ...changes }).success).toBe(false);
		}
	});
});
