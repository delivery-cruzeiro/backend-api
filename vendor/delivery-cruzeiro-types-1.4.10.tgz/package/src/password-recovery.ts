import { z } from 'zod';

const email = z.email().max(254).transform(value => value.trim().toLowerCase());
export const requestPasswordRecoverySchema = z.object({ email }).strict();
export const verifyPasswordRecoverySchema = z.object({
	email,
	code: z.string().regex(/^\d{6}$/),
}).strict();
export const resetRecoveredPasswordSchema = z.object({
	email,
	recoveryAuthorization: z.string().regex(/^[a-f0-9]{64}$/),
	password: z.string().min(8).max(128),
	confirmPassword: z.string().min(8).max(128),
}).strict().refine(value => value.password === value.confirmPassword, {
	message: 'As senhas devem ser iguais', path: ['confirmPassword'],
});
export type RequestPasswordRecoveryDTO = z.infer<typeof requestPasswordRecoverySchema>;
export type VerifyPasswordRecoveryDTO = z.infer<typeof verifyPasswordRecoverySchema>;
export type ResetRecoveredPasswordDTO = z.infer<typeof resetRecoveredPasswordSchema>;
export type PasswordRecoveryVerification = { recoveryAuthorization: string };
