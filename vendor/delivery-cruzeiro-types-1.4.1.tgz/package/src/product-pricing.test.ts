import { describe, expect, it } from 'vitest';
import { calculateProductPrice, createProductSchema, productPricingModeSchema, updateProductSchema } from './index.js';

describe('product pricing', () => {
	it.each([
		['FIXED', 10, 15, 25, true],
		['ADDITIVE', 10, 15, 15, true],
		['ADDITIVE', 10, 10, 10, true],
		['ADDITIVE', 10, 9.99, 9.99, false],
		['ADDITIVE', 10, 0, 0, false],
		['ADDITIVE', 0.3, 0.1 + 0.2, 0.3, true],
	])('%s minimum %s additions %s', (mode, minimum, additions, unitPrice, meetsMinimum) => {
		expect(calculateProductPrice(minimum, additions, mode)).toEqual({ unitPrice, meetsMinimum });
	});
	it('defaults new products to fixed and preserves omitted mode on partial updates', () => {
		expect(createProductSchema.shape.pricingMode.parse(undefined)).toBe('FIXED');
		expect(updateProductSchema.parse({ price: 12 })).toEqual({ price: 12 });
		expect(productPricingModeSchema.safeParse('OTHER').success).toBe(false);
	});
});
