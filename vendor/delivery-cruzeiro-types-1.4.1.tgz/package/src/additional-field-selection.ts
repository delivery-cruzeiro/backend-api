import {
	ProductAdditionalFieldType,
	type ProductAdditionalFieldDTO,
	type ProductAdditionalFieldValueDTO,
} from './index.js';

export function resolveAdditionalFieldSelection(
	field: ProductAdditionalFieldDTO,
	input: unknown
):
	| { success: false; error: string }
	| {
			success: true;
			selected: boolean;
			value: ProductAdditionalFieldValueDTO['value'];
			additionalValue: number;
			description: string;
	  } {
	const fail = (message: string) => ({
		success: false as const,
		error: `${field.label}: ${message}`,
	});
	if (field.type === ProductAdditionalFieldType.MULTI_OPTION) {
		if (input !== undefined && !Array.isArray(input)) return fail('seleção inválida.');
		const options = field.quantityOptions ?? [];
		const selected = new Map<string, number>();
		for (const item of (input ?? []) as unknown[]) {
			if (!item || typeof item !== 'object') return fail('opção inválida.');
			const { optionId, quantity } = item as { optionId: unknown; quantity: unknown };
			if (
				typeof optionId !== 'string' ||
				!options.some(option => option.id === optionId) ||
				selected.has(optionId) ||
				typeof quantity !== 'number' ||
				!Number.isInteger(quantity) ||
				quantity < 0 ||
				quantity > 999
			)
				return fail('opção ou quantidade inválida.');
			selected.set(optionId, quantity);
		}
		const total = [...selected.values()].reduce((sum, quantity) => sum + quantity, 0);
		if (!total && !field.required)
			return {
				success: true,
				selected: false,
				value: [],
				additionalValue: 0,
				description: '',
			};
		const minimum = Math.max(field.minQuantity ?? 0, field.required ? 1 : 0);
		if (total < minimum) return fail(`selecione pelo menos ${minimum} item(ns).`);
		if (field.maxQuantity !== undefined && total > field.maxQuantity)
			return fail(`selecione no máximo ${field.maxQuantity} item(ns).`);
		let cents = 0;
		const value: Extract<ProductAdditionalFieldValueDTO['value'], unknown[]> = [];
		for (const option of options) {
			const quantity = selected.get(option.id) ?? 0;
			if (quantity < (option.minQuantity ?? 0) || quantity > (option.maxQuantity ?? 999))
				return fail(
					`${option.label} deve ter entre ${option.minQuantity ?? 0} e ${option.maxQuantity ?? 999} unidade(s).`
				);
			if (quantity) {
				value.push({ optionId: option.id, quantity, label: option.label });
				cents += Math.round((option.additionalValue ?? 0) * 100) * quantity;
			}
		}
		return {
			success: true,
			selected: total > 0,
			value,
			additionalValue: cents / 100,
			description: value.map(option => `${option.label} × ${option.quantity}`).join(', '),
		};
	}
	const empty =
		input === undefined || input === false || (typeof input === 'string' && !input.trim());
	if (empty)
		return field.required
			? fail('campo obrigatório.')
			: {
					success: true,
					selected: false,
					value: field.type === ProductAdditionalFieldType.CHECKBOX ? false : '',
					additionalValue: 0,
					description: '',
				};
	const valid =
		field.type === ProductAdditionalFieldType.CHECKBOX
			? input === true
			: typeof input === 'string' &&
				(field.type === ProductAdditionalFieldType.TEXT || field.options.includes(input));
	if (!valid) return fail('valor inválido.');
	const value = typeof input === 'string' ? input.trim() : true;
	return {
		success: true,
		selected: true,
		value,
		additionalValue: field.additionalValue ?? 0,
		description: value === true ? field.label : value,
	};
}
