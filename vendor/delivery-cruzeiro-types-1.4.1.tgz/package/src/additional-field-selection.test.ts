import { describe, expect, it } from 'vitest';
import {
	ProductAdditionalFieldType as Type,
	productAdditionalFieldSchema,
	resolveAdditionalFieldSelection,
	type ProductAdditionalFieldDTO,
} from './index.js';

const list: ProductAdditionalFieldDTO = {
	id: 'shopping',
	label: 'Lista de compra',
	type: Type.MULTI_OPTION,
	options: [],
	required: true,
	minQuantity: 2,
	maxQuantity: 5,
	quantityOptions: [
		{ id: 'potato', label: 'Batata', additionalValue: 1.25, maxQuantity: 3 },
		{ id: 'rice', label: 'Arroz', additionalValue: 2.1, minQuantity: 1, maxQuantity: 3 },
	],
};
const selection = [
	{ optionId: 'potato', quantity: 2, label: 'alterado' },
	{ optionId: 'rice', quantity: 1 },
];
describe('additional field configuration and selection', () => {
	it('calculates individual prices and canonical option labels', () => {
		expect(resolveAdditionalFieldSelection(list, selection)).toMatchObject({
			success: true,
			additionalValue: 4.6,
			value: [
				{ optionId: 'potato', quantity: 2, label: 'Batata' },
				{ optionId: 'rice', quantity: 1, label: 'Arroz' },
			],
		});
	});
	it.each([
		undefined,
		[],
		[{ optionId: 'potato', quantity: 2 }],
		[{ optionId: 'rice', quantity: 1 }],
		[
			{ optionId: 'rice', quantity: 3 },
			{ optionId: 'potato', quantity: 3 },
		],
		[{ optionId: 'rice', quantity: 4 }],
		[{ optionId: 'rice', quantity: -1 }],
		[{ optionId: 'rice', quantity: 1.5 }],
		[
			{ optionId: 'rice', quantity: 1 },
			{ optionId: 'rice', quantity: 1 },
		],
		[{ optionId: 'unknown', quantity: 2 }],
	])('rejects missing, out of bounds or forged selections: %j', input => {
		expect(resolveAdditionalFieldSelection(list, input).success).toBe(false);
	});
	it('allows an optional list to stay empty while validating partial selections', () => {
		const optional = { ...list, required: false };
		expect(resolveAdditionalFieldSelection(optional, undefined)).toMatchObject({
			success: true,
			selected: false,
			additionalValue: 0,
		});
		expect(
			resolveAdditionalFieldSelection(optional, [{ optionId: 'potato', quantity: 2 }]).success
		).toBe(false);
	});
	it.each([Type.TEXT, Type.CHECKBOX, Type.COMBOBOX, Type.RADIO])(
		'keeps legacy %s optional and enforces explicit required',
		type => {
			const field = {
				id: 'old',
				label: 'Antigo',
				type,
				options: type === Type.COMBOBOX || type === Type.RADIO ? ['A'] : [],
			};
			expect(productAdditionalFieldSchema.safeParse(field).success).toBe(true);
			expect(resolveAdditionalFieldSelection(field, undefined)).toMatchObject({
				success: true,
				selected: false,
			});
			expect(
				resolveAdditionalFieldSelection({ ...field, required: true }, undefined).success
			).toBe(false);
			expect(
				resolveAdditionalFieldSelection(
					{ ...field, required: true },
					type === Type.CHECKBOX ? true : 'A'
				).success
			).toBe(true);
		}
	);
	it.each([
		{ minQuantity: 6 },
		{ quantityOptions: [] },
		{ quantityOptions: [{ id: 'a', label: 'A', maxQuantity: 6 }] },
		{ quantityOptions: [{ id: 'a', label: 'A', minQuantity: 3, maxQuantity: 2 }] },
		{
			quantityOptions: [
				{ id: 'a', label: 'A', minQuantity: 3 },
				{ id: 'b', label: 'B', minQuantity: 3 },
			],
		},
		{ quantityOptions: [{ id: 'a', label: 'A', maxQuantity: 1 }] },
		{
			quantityOptions: [
				{ id: 'a', label: 'A' },
				{ id: 'a', label: 'B' },
			],
		},
	])('rejects unreachable and contradictory configurations: %j', changes => {
		expect(productAdditionalFieldSchema.safeParse({ ...list, ...changes }).success).toBe(false);
	});
});
