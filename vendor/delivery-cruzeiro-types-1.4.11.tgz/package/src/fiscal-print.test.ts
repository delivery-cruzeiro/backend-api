import { describe, expect, it } from 'vitest';
import { fiscalPrintLayoutSchema, resolveFiscalPrintLayout } from './fiscal-print.js';
describe('modelo fiscal de impressão', () => {
	it('produz padrões independentes sem remover dados fiscais', () => {
		const first = resolveFiscalPrintLayout();
		first.feedLines = 20;
		expect(resolveFiscalPrintLayout().feedLines).toBe(4);
		expect(
			fiscalPrintLayoutSchema.safeParse({ ...resolveFiscalPrintLayout(), hideQr: true })
				.success
		).toBe(false);
	});
	it.each([{ fontSize: 0 }, { feedLines: 21 }, { headerFontSize: 100 }])(
		'recusa impressão ilegível ou avanço inválido',
		change => {
			expect(
				fiscalPrintLayoutSchema.safeParse({ ...resolveFiscalPrintLayout(), ...change })
					.success
			).toBe(false);
		}
	);
});
