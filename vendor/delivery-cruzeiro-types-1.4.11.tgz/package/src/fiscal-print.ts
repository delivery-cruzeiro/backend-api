import { z } from 'zod';

export const fiscalPrintLayoutSchema = z
	.object({
		version: z.literal(1),
		fontSize: z.number().int().min(18).max(24),
		headerFontSize: z.number().int().min(24).max(36),
		feedLines: z.number().int().min(0).max(20),
		showTradeName: z.boolean(),
		compactItems: z.boolean(),
	})
	.strict();
export type FiscalPrintLayout = z.infer<typeof fiscalPrintLayoutSchema>;
export function resolveFiscalPrintLayout(value?: FiscalPrintLayout | null): FiscalPrintLayout {
	return (
		value ?? {
			version: 1,
			fontSize: 20,
			headerFontSize: 28,
			feedLines: 4,
			showTradeName: true,
			compactItems: false,
		}
	);
}
export interface FiscalReceiptData {
	accessKey: string;
	authorizationDate: string | null;
	contingency: boolean;
	emit: {
		city: string;
		cnpj: string;
		ie: string | null;
		name: string;
		neighborhood: string;
		number: string;
		state: string;
		street: string;
		tradeName: string | null;
		zipCode: string;
	};
	environment: string;
	fiscalNumber: string;
	issuedAt: string;
	model: string;
	payments: Array<{ amount: string; type: string }>;
	products: Array<{
		name: string;
		quantity: string;
		total: string;
		unitValue: string;
		code?: string;
		unit?: string;
	}>;
	protocol: string | null;
	qrCodeUrl: string;
	serie: string;
	total: string;
	recipient?: { name: string; id: string; address: string; idType?: string };
	discount?: string;
	freight?: string;
	insurance?: string;
	otherCharges?: string;
	change?: string;
	estimatedTaxes?: string;
	additionalInfo?: string;
	consultationUrl?: string;
}
