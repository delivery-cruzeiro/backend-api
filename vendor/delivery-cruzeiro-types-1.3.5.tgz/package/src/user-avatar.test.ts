import { describe, expect, it } from 'vitest';
import { USER_AVATAR_IDS, updateClientProfileSchema } from './index.js';

describe('profile avatar contract', () => {
	it('accepts each catalog ID and the explicit empty choice', () => {
		for (const avatar of [...USER_AVATAR_IDS, null]) {
			expect(updateClientProfileSchema.parse({ name: 'Cliente', avatar }).avatar).toBe(avatar);
		}
	});
	it('rejects URLs, anchor, unknown IDs and image data', () => {
		for (const avatar of ['https://example.com/man-1.png', 'anchor', 'unknown', 'data:image/png;base64,AA', '']) {
			expect(updateClientProfileSchema.safeParse({ name: 'Cliente', avatar }).success).toBe(false);
		}
	});
});
