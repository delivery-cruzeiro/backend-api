import { describe, expect, it } from 'vitest';
import { PaymentType, createStorePaymentMethodSchema, updateStorePaymentMethodSchema } from './index.js';

describe('campos do pagamento', () => {
 it('cria método independente sem exigir tipo predefinido', () => {
  const result = createStorePaymentMethodSchema.parse({ storeId: 'cstore00000000000000000000', name: 'Vale local' });
  expect(result.type).toBe(PaymentType.CUSTOM);
  expect(result.fields).toEqual([]);
 });
 it('preserva campos e tipo ao ativar ou desativar método', () => {
  expect(updateStorePaymentMethodSchema.parse({ isActive: false })).toEqual({ isActive: false });
  expect(updateStorePaymentMethodSchema.parse({ name: 'Novo nome' })).toEqual({ name: 'Novo nome' });
 });
 it('permite limpar campos explicitamente e rejeita atualização vazia', () => {
  expect(updateStorePaymentMethodSchema.parse({ fields: [] })).toEqual({ fields: [] });
  expect(updateStorePaymentMethodSchema.safeParse({}).success).toBe(false);
 });
});
