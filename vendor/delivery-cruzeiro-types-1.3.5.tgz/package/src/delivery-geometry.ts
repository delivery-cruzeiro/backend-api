import clipping from 'polygon-clipping';
import { z } from 'zod';

export type Position = [number, number];
export type DeliveryGeometry = { type: 'Polygon'; coordinates: Position[][] } | { type: 'MultiPolygon'; coordinates: Position[][][] };
const position = z.tuple([z.number().finite().min(-180).max(180), z.number().finite().min(-85).max(85)]);
export const deliveryCutSchema = z.object({ target: z.number().int().min(0).max(63), start: position, end: position }).strict();
export const deliveryPartitionSchema = z.object({
  storeId: z.string().uuid(), neighborhoodId: z.string().uuid(), baseRevision: z.literal(0),
  sourceHash: z.string().min(1).max(128), cuts: z.array(deliveryCutSchema).min(1).max(32),
  requestId: z.string().uuid(),
}).strict();
export type DeliveryCut = z.infer<typeof deliveryCutSchema>;
export type DeliveryPartitionInput = z.infer<typeof deliveryPartitionSchema>;
export type DeliveryMapFeature = { type: 'Feature'; geometry: DeliveryGeometry; properties: {
  id: string; neighborhoodId: string; name: string; parentName: string; areaId: string | null;
  revision: number; sourceHash: string; deliveryStatus?: string;
} };
export type DeliveryOperationalMap = { type: 'FeatureCollection'; features: DeliveryMapFeature[] };
export const normalizeDeliveryName = (name: string) => name.normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toUpperCase();

const R = 6378137;
const project = ([x, y]: Position): Position => [R * x * Math.PI / 180, R * Math.log(Math.tan(Math.PI / 4 + y * Math.PI / 360))];
const unproject = ([x, y]: Position): Position => [x / R * 180 / Math.PI, (2 * Math.atan(Math.exp(y / R)) - Math.PI / 2) * 180 / Math.PI];
const polygons = (g: DeliveryGeometry): Position[][][] => g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
const ringArea = (r: Position[]) => Math.abs(r.reduce((s, p, i) => { const n = r[(i + 1) % r.length]; return s + p[0] * n[1] - n[0] * p[1]; }, 0) / 2);
const area = (ps: Position[][][]) => ps.reduce((sum, p) => sum + ringArea(p[0]) - p.slice(1).reduce((s, r) => s + ringArea(r), 0), 0);
export function splitDeliveryGeometry(geometry: DeliveryGeometry, cuts: DeliveryCut[]): DeliveryGeometry[] {
  const raw = polygons(geometry);
  if (raw.flat(2).length > 100000 || cuts.length > 32) throw new Error('Mapa ou quantidade de cortes excede o limite.');
  for (const poly of raw) for (const ring of poly) {
    if (ring.length < 4 || ring.some(p => !position.safeParse(p).success) || ring[0][0] !== ring.at(-1)![0] || ring[0][1] !== ring.at(-1)![1]) throw new Error('Contorno inválido.');
  }
  const original = raw.map(p => p.map(r => r.map(project)));
  let parts: Position[][][][] = [original];
  for (const [index, cut] of cuts.entries()) {
    const subject = parts[cut.target];
    if (!subject) throw new Error(`Corte ${index + 1}: selecione uma área válida.`);
    const a = project(cut.start), b = project(cut.end);
    const dx = b[0] - a[0], dy = b[1] - a[1], length = Math.hypot(dx, dy);
    if (length < 0.1) throw new Error(`Corte ${index + 1}: os pontos devem ser diferentes.`);
    const extent = Math.max(...subject.flat(2).map(p => Math.hypot(p[0] - a[0], p[1] - a[1]))) * 4 + 100;
    const u: Position = [dx / length * extent, dy / length * extent];
    const v: Position = [-u[1], u[0]];
    const left: Position = [a[0] - u[0], a[1] - u[1]], right: Position = [a[0] + u[0], a[1] + u[1]];
    const halves = [1, -1].map(sign => clipping.intersection(subject, [[left, right, [right[0] + sign * v[0], right[1] + sign * v[1]], [left[0] + sign * v[0], left[1] + sign * v[1]], left]]) as Position[][][]);
    if (halves.some(p => !p.length)) throw new Error(`Corte ${index + 1}: a reta precisa atravessar a área.`);
    const results = halves.flatMap(h => h.map(p => [p]));
    if (results.some(p => area(p) < 1)) throw new Error(`Corte ${index + 1}: gera uma área menor que 1 m² na projeção do mapa.`);
    if (area(clipping.intersection(halves[0], halves[1]) as Position[][][]) > 0.01) throw new Error('Áreas sobrepostas.');
    parts.splice(cut.target, 1, ...results);
    if (parts.length > 64) throw new Error('Limite de 64 divisões por bairro.');
  }
  const union = clipping.union(...parts as [Position[][][], ...Position[][][][]]) as Position[][][];
  const delta = area(clipping.xor(original, union) as Position[][][]);
  if (delta > Math.max(0.01, area(original) * 1e-8)) throw new Error('As divisões não preservam o contorno original.');
  return parts.map(p => ({ type: 'MultiPolygon', coordinates: p.map(rings => rings.map(r => r.map(unproject))) }));
}

// Boundary inclusion is deliberate; the caller chooses blocked areas first, then index.
export function deliveryGeometryCovers(geometry: DeliveryGeometry, point: Position): boolean {
  const p = project(point);
  const inRing = (ring: Position[]): 0 | 1 | 2 => {
    const r = ring.map(project); let inside = false;
    for (let i = 0, j = r.length - 1; i < r.length; j = i++) {
      const a = r[j], b = r[i], dx = b[0] - a[0], dy = b[1] - a[1];
      const len = Math.hypot(dx, dy);
      if (len > 0 && Math.abs(dx * (p[1] - a[1]) - dy * (p[0] - a[0])) / len < 0.001 && p[0] >= Math.min(a[0], b[0]) - 0.001 && p[0] <= Math.max(a[0], b[0]) + 0.001 && p[1] >= Math.min(a[1], b[1]) - 0.001 && p[1] <= Math.max(a[1], b[1]) + 0.001) return 2;
      if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < dx * (p[1] - a[1]) / dy + a[0]) inside = !inside;
    }
    return inside ? 1 : 0;
  };
  return polygons(geometry).some(poly => { const outer = inRing(poly[0]); return outer === 2 || (outer === 1 && !poly.slice(1).some(h => inRing(h) === 1)); });
}
