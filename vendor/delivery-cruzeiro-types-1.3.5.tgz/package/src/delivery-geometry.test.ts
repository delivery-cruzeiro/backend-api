import { describe, expect, it } from 'vitest';
import { deliveryGeometryCovers, deliveryPartitionSchema, splitDeliveryGeometry, type DeliveryGeometry } from './delivery-geometry.js';
const square: DeliveryGeometry = { type: 'Polygon', coordinates: [[[0,0],[.01,0],[.01,.01],[0,.01],[0,0]]] };
describe('delivery geometry', () => {
  it('splits sequentially and preserves both sides of the boundary', () => {
    const cut = { target: 0, start: [.005,0] as [number,number], end: [.005,.01] as [number,number] };
    const parts = splitDeliveryGeometry(square, [cut]);
    expect(parts).toHaveLength(2);
    expect(parts.filter(p => deliveryGeometryCovers(p, [.005,.005]))).toHaveLength(2);
    expect(parts.filter(p => deliveryGeometryCovers(p, [.002,.005]))).toHaveLength(1);
    expect(splitDeliveryGeometry(square, [cut, { target: 0, start: [0,.005], end: [.01,.005] }])).toHaveLength(3);
  });
  it('rejects tangent, duplicate, zero length and tiny slivers', () => {
    expect(() => splitDeliveryGeometry(square, [{ target: 0, start: [0,0], end: [.01,0] }])).toThrow();
    expect(() => splitDeliveryGeometry(square, [{ target: 0, start: [0,0], end: [0,0] }])).toThrow();
    expect(() => splitDeliveryGeometry(square, [{ target: 0, start: [1e-9,0], end: [1e-9,.01] }])).toThrow();
    const cut = { target: 0, start: [.005,0] as [number,number], end: [.005,.01] as [number,number] };
    expect(() => splitDeliveryGeometry(square, [cut, cut])).toThrow();
  });
  it('preserves holes and accepts disconnected source components', () => {
    const hole: DeliveryGeometry = { ...square, coordinates: [...square.coordinates, [[.003,.003],[.007,.003],[.007,.007],[.003,.007],[.003,.003]]] };
    const parts = splitDeliveryGeometry(hole, [{ target: 0, start: [.005,0], end: [.005,.01] }]);
    expect(parts.some(p => deliveryGeometryCovers(p, [.005,.005]))).toBe(false);
    expect(parts.some(p => deliveryGeometryCovers(p, [.002,.005]))).toBe(true);
    const multi: DeliveryGeometry = { type: 'MultiPolygon', coordinates: [square.coordinates, square.coordinates.map(r => r.map(([x,y]) => [x+.02,y]))] };
    expect(splitDeliveryGeometry(multi, [{ target: 0, start: [.005,0], end: [.005,.01] }])).toHaveLength(3);
  });
  it('enforces bounded requests and rejects untrusted geometry fields', () => {
    expect(deliveryPartitionSchema.safeParse({ geometry: square }).success).toBe(false);
  });
});
