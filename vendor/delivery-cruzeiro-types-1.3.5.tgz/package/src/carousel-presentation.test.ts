import { describe, expect, it } from 'vitest';
import {
	CarouselSize,
	SystemLayout,
	carouselContentSchema,
	getCarouselPresentation,
} from './index.js';

describe('carousel sizes', () => {
	it('preserves each theme default for existing content without a size', () => {
		expect(getCarouselPresentation(SystemLayout.CRAVE_MARKET)).toMatchObject({
			size: CarouselSize.LARGE,
			desktopHeight: 384,
		});
		expect(getCarouselPresentation(SystemLayout.MOTION_CANVAS)).toMatchObject({
			size: CarouselSize.MEDIUM,
			desktopHeight: 220,
		});
	});
	it('accepts the three sizes and rejects arbitrary sizes', () => {
		const content = {
			durationSeconds: 5,
			transition: 'FADE',
			slides: [{ html: '', imageUrl: 'https://example.com/image.jpg' }],
		};
		expect(carouselContentSchema.parse(content).size).toBeUndefined();
		for (const size of Object.values(CarouselSize))
			expect(carouselContentSchema.parse({ ...content, size }).size).toBe(size);
		expect(carouselContentSchema.safeParse({ ...content, size: 'CUSTOM' }).success).toBe(false);
	});
	it('keeps heights ordered in every theme without sharing another carousel size', () => {
		for (const layout of Object.values(SystemLayout)) {
			const small = getCarouselPresentation(layout, CarouselSize.SMALL);
			const medium = getCarouselPresentation(layout, CarouselSize.MEDIUM);
			const large = getCarouselPresentation(layout, CarouselSize.LARGE);
			expect(small.desktopHeight).toBeLessThan(medium.desktopHeight);
			expect(medium.desktopHeight).toBeLessThan(large.desktopHeight);
			expect(getCarouselPresentation(layout, CarouselSize.SMALL)).toEqual(small);
		}
	});
});
