import { describe, expect, it } from 'vitest';
import {
	CarouselTransition,
	createBadgeSchema,
	createCarouselSchema,
	createWhatsAppMessageConfigurationSchema,
	createMenuSchema,
	createOrderSchema,
	createPrinterConfigurationSchema,
	createUserGroupSchema,
	createSubcategorySchema,
	formatZodError,
	listAdminOrdersQuerySchema,
	loginUserSchema,
	productAdditionalFieldSchema,
	registerUserSchema,
	searchUserGroupUsersSchema,
	setBadgeProductsSchema,
	setPrinterAssignmentsSchema,
	themeNameSchema,
	updateAdminOrderStatusSchema,
	updateDefaultShippingSchema,
	upsertNeighborhoodShippingSchema,
	UserGroupLogicalOperator,
	UserGroupMode,
	UserGroupRuleOperator,
	UserGroupRuleSource,
	PrinterConnectionStatus,
	WhatsAppMessageLocation,
	WhatsAppMessageOperation,
} from './index';

describe('shared Zod schemas', () => {
	const registration = { email: 'cliente@example.com', password: 'secret123', name: 'Cliente', phone: '11999999999' };
	it.each([undefined, null])('accepts optional CPF %s', cpf => {
		expect(registerUserSchema.safeParse({ ...registration, cpf }).success).toBe(true);
	});
	it.each([undefined, null, '', '   '])('rejects missing phone %s', phone => {
		expect(registerUserSchema.safeParse({ ...registration, phone }).success).toBe(false);
	});
	it('normalizes valid CPF and rejects invalid check digits', () => {
		expect(registerUserSchema.parse({ ...registration, cpf: '529.982.247-25' }).cpf).toBe('52998224725');
		expect(registerUserSchema.safeParse({ ...registration, cpf: '11111111111' }).success).toBe(false);
		expect(registerUserSchema.safeParse({ ...registration, cpf: '52998224724' }).success).toBe(false);
	});
	it('validates register user payloads', () => {
		const result = registerUserSchema.safeParse({
			email: 'cliente@example.com',
			password: 'secret123',
			name: 'Cliente Teste',
			phone: '11999999999',
		});

		expect(result.success).toBe(true);
	});

	it('rejects invalid login payloads', () => {
		const result = loginUserSchema.safeParse({
			email: 'invalid-email',
			password: '',
		});

		expect(result.success).toBe(false);
	});

	it('requires at least one order item', () => {
		const result = createOrderSchema.safeParse({
			addressId: 'address_1',
			items: [],
			storeId: 'store-1',
		});

		expect(result.success).toBe(false);
	});

	it('validates the optional additional price limit', () => {
		const field = {
			additionalValue: 123.45,
			id: 'field-1',
			label: 'Borda recheada',
			type: 'CHECKBOX',
		};

		expect(productAdditionalFieldSchema.safeParse(field).success).toBe(true);
		expect(
			productAdditionalFieldSchema.safeParse({ ...field, additionalValue: 1000 }).success
		).toBe(false);
	});

	it('validates admin order filters and status updates', () => {
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'ALL' }).success).toBe(true);
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'PREPARING' }).success).toBe(true);
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'UNKNOWN' }).success).toBe(false);

		expect(updateAdminOrderStatusSchema.safeParse({ status: 'DELIVERED' }).success).toBe(true);
		expect(updateAdminOrderStatusSchema.safeParse({ status: 'UNKNOWN' }).success).toBe(false);
	});

	it('validates menu and subcategory payloads', () => {
		expect(
			createMenuSchema.safeParse({
				name: 'Cardapio principal',
				categoryIds: ['category-1'],
				subcategoryIds: ['subcategory-1'],
				storeIds: ['store-1'],
			}).success
		).toBe(true);
		expect(createMenuSchema.safeParse({ name: '' }).success).toBe(false);

		expect(
			createSubcategorySchema.safeParse({
				categoryId: 'category-1',
				name: 'Pizzas doces',
				storeIds: ['store-1'],
			}).success
		).toBe(true);
		expect(createSubcategorySchema.safeParse({ name: 'Sem categoria' }).success).toBe(false);
	});

	it('validates carousel configuration limits', () => {
		const validCarousel = {
			name: 'Destaques da semana',
			storeId: 'store-1',
			content: {
				durationSeconds: 5,
				transition: CarouselTransition.FADE,
				slides: [
					{
						html: '<h2>Oferta</h2>',
						imageUrl: 'https://example.com/banner.jpg',
					},
				],
			},
		};

		expect(createCarouselSchema.safeParse(validCarousel).success).toBe(true);
		expect(
			createCarouselSchema.safeParse({
				...validCarousel,
				content: { ...validCarousel.content, durationSeconds: 0 },
			}).success
		).toBe(false);
		expect(
			createCarouselSchema.safeParse({
				...validCarousel,
				content: { ...validCarousel.content, slides: [] },
			}).success
		).toBe(false);
	});

	it('validates badge metadata and product assignments', () => {
		expect(
			createBadgeSchema.safeParse({
				color: '#2563EB',
				icon: 'verified',
				name: 'Destaque',
				storeId: 'store-1',
			}).success
		).toBe(true);
		expect(
			createBadgeSchema.safeParse({
				color: 'blue',
				name: 'Destaque',
				storeId: 'store-1',
			}).success
		).toBe(false);
		expect(
			setBadgeProductsSchema.safeParse({ productIds: ['product-1', 'product-2'] }).success
		).toBe(true);
	});

	it('validates default shipping updates', () => {
		expect(
			updateDefaultShippingSchema.safeParse({
				shippingTime: 45,
				storeId: 'store-1',
				value: 7.5,
			}).success
		).toBe(true);
		expect(
			updateDefaultShippingSchema.safeParse({
				shippingTime: -1,
				storeId: 'store-1',
				value: -5,
			}).success
		).toBe(false);
	});

	it('defaults neighborhood delivery blocking to disabled', () => {
		const result = upsertNeighborhoodShippingSchema.parse({
			mode: 'DEFAULT',
			neighborhood: 'Centro',
			storeId: 'store-1',
		});

		expect(result.isBlocked).toBe(false);
		expect(
			upsertNeighborhoodShippingSchema.parse({
				...result,
				isBlocked: true,
			}).isBlocked
		).toBe(true);
	});

	it('accepts a null template name when saving manual subdivision settings', () => {
		const input = {
			areaId: 'd0206578-8b08-425a-94ce-aa902faf7768',
			createTemplate: false, isBlocked: true, mode: 'MANUAL',
			neighborhood: 'Liberdade-1', shippingTime: 30,
			storeId: 'fe8215f0-e578-4cca-a9b4-4d8c7fd7f473', templateName: null, value: 12,
		};
		expect(upsertNeighborhoodShippingSchema.parse(input)).toMatchObject(input);
		expect(upsertNeighborhoodShippingSchema.parse({ ...input, isBlocked: false }).isBlocked).toBe(false);
		expect(upsertNeighborhoodShippingSchema.safeParse({ ...input, value: null }).success).toBe(false);
		expect(upsertNeighborhoodShippingSchema.safeParse({ ...input, templateName: 123 }).success).toBe(false);
	});
	it('formats zod errors as api errors', () => {
		const result = loginUserSchema.safeParse({
			email: 'invalid-email',
			password: '',
		});

		expect(result.success).toBe(false);

		if (!result.success) {
			expect(formatZodError(result.error)).toMatchObject({
				code: 'VALIDATION_ERROR',
				statusCode: 400,
			});
		}
	});

	it('validates supported theme names', () => {
		expect(themeNameSchema.safeParse('default').success).toBe(true);
		expect(themeNameSchema.safeParse('cruzeiro').success).toBe(true);
		expect(themeNameSchema.safeParse('dark').success).toBe(false);
	});

	it('validates declarative user group rules and keeps manual groups compatible', () => {
		const manualGroup = createUserGroupSchema.parse({ name: 'Clientes recorrentes' });
		expect(manualGroup).toMatchObject({
			mode: UserGroupMode.MANUAL,
			rules: [],
			userIds: [],
		});

		expect(
			createUserGroupSchema.safeParse({
				mode: UserGroupMode.RULE,
				name: 'Clientes premium',
				rules: [],
			}).success
		).toBe(false);

		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{
						field: 'gender',
						operator: UserGroupRuleOperator.EQUAL,
						source: UserGroupRuleSource.USER,
						value: 'MALE',
					},
					{
						field: 'total',
						logicalOperator: UserGroupLogicalOperator.AND,
						operator: UserGroupRuleOperator.GREATER_THAN_OR_EQUAL,
						source: UserGroupRuleSource.ORDER,
						value: 100,
					},
				],
			}).success
		).toBe(true);
	});

	it('rejects arbitrary fields and missing logical operators in user group rules', () => {
		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{
						field: 'password',
						operator: '==',
						source: 'user',
						value: 'secret',
					},
				],
			}).success
		).toBe(false);

		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{ field: 'name', operator: '==', source: 'user', value: 'Ana' },
					{ field: 'status', operator: '==', source: 'order', value: 'DELIVERED' },
				],
			}).success
		).toBe(false);
	});

	it('validates automatic WhatsApp message configurations', () => {
		expect(
			createWhatsAppMessageConfigurationSchema.safeParse({
				location: WhatsAppMessageLocation.PREPARING,
				operation: WhatsAppMessageOperation.ENTRY,
				template: {
					html: '<p>Olá &lt;nome&gt;</p>',
					version: 1,
				},
			}).success
		).toBe(true);

		expect(
			createWhatsAppMessageConfigurationSchema.safeParse({
				location: 'PREPARING',
				operation: 'DURING',
				template: { html: '', version: 1 },
			}).success
		).toBe(false);
	});

	it('validates printer configuration and normalized assignments', () => {
		expect(setPrinterAssignmentsSchema.parse({ receiptSections: [] }).receiptSections).toEqual([]);
		expect(setPrinterAssignmentsSchema.safeParse({ receiptSections: ['customer', 'payment'] }).success).toBe(true);
		expect(setPrinterAssignmentsSchema.safeParse({ receiptSections: ['unknown'] }).success).toBe(false);
		expect(createPrinterConfigurationSchema.safeParse({
			storeId: 'store-1',
			connectionId: 'webserial:123:456:0',
			name: 'Cozinha',
			connectionStatus: PrinterConnectionStatus.CONNECTED,
		}).success).toBe(true);
		expect(setPrinterAssignmentsSchema.safeParse({
			categoryIds: ['category-1'],
			subcategoryIds: ['subcategory-1'],
		}).success).toBe(true);
		expect(createPrinterConfigurationSchema.safeParse({
			storeId: 'store-1',
			connectionId: '',
			name: '',
		}).success).toBe(false);
	});
});

