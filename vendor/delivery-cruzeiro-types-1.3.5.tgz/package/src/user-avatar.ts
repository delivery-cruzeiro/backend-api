/** Stable identifiers persisted in User.avatar; asset URLs belong to the frontend. */
export const USER_AVATAR_IDS = [
	'man-1', 'man-2', 'man-3', 'man-4', 'man-5',
	'woman-1', 'woman-2', 'woman-3', 'woman-4',
] as const;

export type UserAvatarId = (typeof USER_AVATAR_IDS)[number];
