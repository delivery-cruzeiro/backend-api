import { describe, expect, it } from 'vitest';
import { sendWhatsAppTextSchema } from './index';

describe('WhatsApp recipient normalization', () => {
	it.each([
		['(83) 99999-9999', '5583999999999'],
		['83 3333-4444', '558333334444'],
		['83999999999', '5583999999999'],
		['+55 (83) 99999-9999', '5583999999999'],
		['5583999999999', '5583999999999'],
		['0055 83 99999-9999', '5583999999999'],
		['+1 (202) 555-0123', '12025550123'],
	])('normalizes %s without duplicating the country code', (phone, expected) => {
		expect(sendWhatsAppTextSchema.parse({ phone, message: 'Pedido confirmado' }).phone).toBe(expected);
	});
	it.each(['', '9999', '+', 'telefone 83999999999', '83999999999 ramal 1', '++5583999999999', '0000000000000', '1234567890123456'])('rejects invalid recipient %s', phone => {
		expect(sendWhatsAppTextSchema.safeParse({ phone, message: 'Teste' }).success).toBe(false);
	});
});
