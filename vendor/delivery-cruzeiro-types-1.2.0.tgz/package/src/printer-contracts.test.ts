import { describe, expect, it } from 'vitest';
import { createPrinterConfigurationSchema, updatePrinterConfigurationSchema } from './index.js';
const serial = { storeId: 'clxxxxxxxxxxxxxxxxxxxxxxx', connectionId: 'port:1', name: 'Serial' };
const windows = {
	...serial,
	transport: 'WINDOWS_BRIDGE',
	windowsQueueId: 'q1',
	windowsQueueName: 'Queue',
	windowsDriverName: 'Driver',
	windowsCapabilities: { raw: true },
	adapterId: 'esc-pos',
	columns: 48,
	encoding: 'cp850',
	autoCut: true,
	copies: 1,
};
describe('printer transport contracts', () => {
	it('preserves legacy serial and rejects Windows metadata on serial', () => {
		expect(createPrinterConfigurationSchema.safeParse(serial).success).toBe(true);
		expect(
			createPrinterConfigurationSchema.safeParse({ ...serial, windowsQueueId: 'q1' }).success
		).toBe(false);
	});
	it('requires Windows identity and operating configuration', () => {
		expect(createPrinterConfigurationSchema.safeParse(windows).success).toBe(true);
		expect(
			createPrinterConfigurationSchema.safeParse({ ...windows, windowsQueueId: undefined })
				.success
		).toBe(false);
		expect(
			createPrinterConfigurationSchema.safeParse({ ...windows, columns: undefined }).success
		).toBe(false);
	});
	it('rejects incompatible raw, cut, encoding and copies', () => {
		for (const change of [
			{ windowsCapabilities: { raw: false } },
			{ adapterId: 'generic', autoCut: true },
			{ encoding: 'utf8' },
			{ copies: 11 },
		])
			expect(
				createPrinterConfigurationSchema.safeParse({ ...windows, ...change }).success
			).toBe(false);
	});
	it('validates partial operational updates', () => {
		expect(updatePrinterConfigurationSchema.safeParse({ copies: 0 }).success).toBe(false);
		expect(updatePrinterConfigurationSchema.safeParse({ encoding: 'ascii' }).success).toBe(
			true
		);
	});
});
