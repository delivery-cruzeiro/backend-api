# @delivery-cruzeiro/types

Tipos TypeScript compartilhados entre frontend e backend do sistema Delivery Cruzeiro.

## Propósito

Este repositório contém todos os tipos TypeScript compartilhados entre as aplicações frontend e backend. Isso garante:

- **Type-safety**: Frontend e backend usam os mesmos tipos, evitando incompatibilidades
- **Single Source of Truth**: Tipos definidos em um único lugar
- **Facilidade de manutenção**: Alterações nos tipos são propagadas automaticamente
- **Autocompletion**: Melhor experiência de desenvolvimento com IntelliSense

## Instalação

Este pacote é instalado como workspace dependency via pnpm:

```bash
# No diretório raiz (onde está o pnpm-workspace.yaml)
pnpm install
```

## Estrutura

```
shared-types/
├── src/
│   └── index.ts          # Todos os tipos exportados
├── dist/                 # TypeScript compilado (gerado automaticamente)
├── package.json
├── tsconfig.json
└── README.md
```

## Categorias de Tipos

Os contratos de entrada compartilhados sao definidos com Zod em `src/index.ts`.
Sempre que um payload trafegar entre frontend e backend, crie ou reutilize um
schema neste pacote e derive o DTO com `z.infer`.

### 1. Enums
- `UserRole`: Papéis de usuário (client, admin, manager, super-admin)
- `OrderStatus`: Status de pedido (pending, approved, preparing, etc.)
- `PaymentStatus`: Status de pagamento (pending, completed, failed, etc.)
- `PromotionType`: Tipos de promoção (percentage, fixed, buy_x_get_y)

### 2. User Types
- `User`: Usuário básico
- `UserWithSensitive`: Usuário com dados sensíveis (apenas backend)
- `RegisterUserDTO`: DTO para registro
- `LoginUserDTO`: DTO para login

### 3. Address Types
- `Address`: Endereço de entrega
- `AddressDTO`: DTO para criar/atualizar endereço

### 4. Product Types
- `Category`: Categoria de produto
- `Product`: Produto do cardápio
- `ProductDTO`: DTO para criar/atualizar produto

### 5. Order Types
- `Order`: Pedido completo
- `OrderItem`: Item de pedido
- `CreateOrderDTO`: DTO para criar pedido

### 6. Payment Types
- `PaymentMethod`: Método de pagamento salvo
- `Payment`: Pagamento realizado

### 7. Promotion Types
- `Promotion`: Promoção ativa
- `PromotionDTO`: DTO para criar/atualizar promoção

### 8. API Response Types
- `ApiResponse<T>`: Resposta padrão da API
- `PaginatedResponse<T>`: Resposta paginada
- `ApiError`: Erro da API

### 9. Auth Types
- `JwtPayload`: Payload do token JWT
- `AuthResponse`: Resposta de login/registro

### 10. Cart Types (Frontend)
- `CartItem`: Item do carrinho
- `Cart`: Carrinho de compras completo

### 11. System Settings Types
- `SystemSettings`: Configurações do sistema
- `DeliveryZone`: Zona de entrega

### 12. Notification Types
- `Notification`: Notificação do usuário

### 13. Review Types
- `Review`: Avaliação de produto
- `ReviewDTO`: DTO para criar avaliação

### 14. Favorite Types
- `Favorite`: Produto favorito

### 15. Points Types
- `Point`: Transação de pontos
- `UserPoints`: Saldo de pontos do usuário

## Uso no Frontend

```typescript
import {
  User,
  Order,
  OrderStatus,
  ApiResponse,
  registerUserSchema,
  type RegisterUserDTO
} from '@delivery-cruzeiro/types';

// Exemplo de uso em um componente React
interface UserProfileProps {
  user: User;
}

// Exemplo de uso em uma chamada de API
const fetchOrders = async (): Promise<ApiResponse<Order[]>> => {
  const response = await fetch('/api/orders');
  return response.json();
};

// Exemplo de uso de enum
const getOrderStatusLabel = (status: OrderStatus): string => {
  switch (status) {
    case OrderStatus.PENDING:
      return 'Pendente';
    case OrderStatus.APPROVED:
      return 'Aprovado';
    case OrderStatus.DELIVERED:
      return 'Entregue';
    default:
      return status;
  }
};

const parseRegisterPayload = (payload: unknown): RegisterUserDTO => {
  return registerUserSchema.parse(payload);
};
```

## Uso no Backend

```typescript
import { 
  User, 
  CreateOrderDTO, 
  Order, 
  ApiResponse,
  UserRole,
  createOrderSchema,
  formatZodError
} from '@delivery-cruzeiro/types';

// Exemplo de uso em um controller
export const createOrder = async (
  dto: CreateOrderDTO
): Promise<ApiResponse<Order>> => {
  try {
    const order = await orderService.create(dto);
    return {
      success: true,
      data: order
    };
  } catch (error) {
    return {
      success: false,
      error: 'Erro ao criar pedido'
    };
  }
};

const result = createOrderSchema.safeParse(request.body);

if (!result.success) {
  return reply.status(400).send(formatZodError(result.error));
}

// Exemplo de uso em um middleware
export const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  const user = req.user as User;
  if (user.role !== UserRole.ADMIN && user.role !== UserRole.SUPER_ADMIN) {
    return res.status(403).json({ error: 'Acesso negado' });
  }
  next();
};
```

## Desenvolvimento

### Criar um novo schema

1. Defina o schema em `src/index.ts` usando Zod.
2. Exporte o tipo inferido com `z.infer<typeof nomeDoSchema>`.
3. Reutilize o schema no frontend para formularios e no backend para `body`,
   `params` ou `query`.
4. Adicione testes em `src/schemas.test.ts` para payload valido e invalido.

### Compilar os tipos

```bash
pnpm build
```

### Modo de desenvolvimento (watch)

```bash
pnpm dev
```

### Limpar arquivos de build

```bash
pnpm clean
```

## Versionamento

Este pacote segue versionamento semântico (SemVer). Quando alterar tipos:

- **Major (X.0.0)**: Mudanças breaking (remover tipos, alterar propriedades obrigatórias)
- **Minor (0.X.0)**: Novos tipos ou novas propriedades opcionais
- **Patch (0.0.X)**: Correções de bugs ou documentação

## Boas Práticas

1. **Sempre exportar tipos**: Todos os tipos devem ser exportados em `src/index.ts`
2. **Documentação**: Adicionar JSDoc para tipos complexos
3. **DTOs**: Criar DTOs separados para criar/atualizar entidades
4. **Enums**: Usar enums para conjuntos fixos de valores
5. **Genericos**: Usar generics para tipos reutilizáveis (ex: `ApiResponse<T>`)

## Integração com pnpm Workspaces

Este pacote é configurado como workspace dependency nos apps de `apps/*` e no `backend-api`:

```json
// apps/*/package.json e backend-api/package.json
{
  "dependencies": {
    "@delivery-cruzeiro/types": "workspace:*"
  }
}
```

Isso permite que as alterações neste pacote sejam refletidas automaticamente nos outros repositórios sem precisar publicar no npm.

## Licença

MIT
