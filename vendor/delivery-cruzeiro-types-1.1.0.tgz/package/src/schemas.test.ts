import { describe, expect, it } from 'vitest';
import {
	CarouselTransition,
	createBadgeSchema,
	createCarouselSchema,
	createWhatsAppMessageConfigurationSchema,
	createMenuSchema,
	createOrderSchema,
	createPrinterConfigurationSchema,
	createUserGroupSchema,
	createSubcategorySchema,
	formatZodError,
	listAdminOrdersQuerySchema,
	loginUserSchema,
	productAdditionalFieldSchema,
	registerUserSchema,
	searchUserGroupUsersSchema,
	setBadgeProductsSchema,
	setPrinterAssignmentsSchema,
	themeNameSchema,
	updateAdminOrderStatusSchema,
	updateDefaultShippingSchema,
	upsertNeighborhoodShippingSchema,
	UserGroupLogicalOperator,
	UserGroupMode,
	UserGroupRuleOperator,
	UserGroupRuleSource,
	PrinterConnectionStatus,
	WhatsAppMessageLocation,
	WhatsAppMessageOperation,
} from './index';

describe('shared Zod schemas', () => {
	it('validates register user payloads', () => {
		const result = registerUserSchema.safeParse({
			email: 'cliente@example.com',
			password: 'secret123',
			name: 'Cliente Teste',
			phone: '11999999999',
		});

		expect(result.success).toBe(true);
	});

	it('rejects invalid login payloads', () => {
		const result = loginUserSchema.safeParse({
			email: 'invalid-email',
			password: '',
		});

		expect(result.success).toBe(false);
	});

	it('requires at least one order item', () => {
		const result = createOrderSchema.safeParse({
			addressId: 'address_1',
			items: [],
			storeId: 'store-1',
		});

		expect(result.success).toBe(false);
	});

	it('validates the optional additional price limit', () => {
		const field = {
			additionalValue: 123.45,
			id: 'field-1',
			label: 'Borda recheada',
			type: 'CHECKBOX',
		};

		expect(productAdditionalFieldSchema.safeParse(field).success).toBe(true);
		expect(
			productAdditionalFieldSchema.safeParse({ ...field, additionalValue: 1000 }).success
		).toBe(false);
	});

	it('validates admin order filters and status updates', () => {
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'ALL' }).success).toBe(true);
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'PREPARING' }).success).toBe(true);
		expect(listAdminOrdersQuerySchema.safeParse({ status: 'UNKNOWN' }).success).toBe(false);

		expect(updateAdminOrderStatusSchema.safeParse({ status: 'DELIVERED' }).success).toBe(true);
		expect(updateAdminOrderStatusSchema.safeParse({ status: 'UNKNOWN' }).success).toBe(false);
	});

	it('validates menu and subcategory payloads', () => {
		expect(
			createMenuSchema.safeParse({
				name: 'Cardapio principal',
				categoryIds: ['category-1'],
				subcategoryIds: ['subcategory-1'],
				storeIds: ['store-1'],
			}).success
		).toBe(true);
		expect(createMenuSchema.safeParse({ name: '' }).success).toBe(false);

		expect(
			createSubcategorySchema.safeParse({
				categoryId: 'category-1',
				name: 'Pizzas doces',
				storeIds: ['store-1'],
			}).success
		).toBe(true);
		expect(createSubcategorySchema.safeParse({ name: 'Sem categoria' }).success).toBe(false);
	});

	it('validates carousel configuration limits', () => {
		const validCarousel = {
			name: 'Destaques da semana',
			storeId: 'store-1',
			content: {
				durationSeconds: 5,
				transition: CarouselTransition.FADE,
				slides: [
					{
						html: '<h2>Oferta</h2>',
						imageUrl: 'https://example.com/banner.jpg',
					},
				],
			},
		};

		expect(createCarouselSchema.safeParse(validCarousel).success).toBe(true);
		expect(
			createCarouselSchema.safeParse({
				...validCarousel,
				content: { ...validCarousel.content, durationSeconds: 0 },
			}).success
		).toBe(false);
		expect(
			createCarouselSchema.safeParse({
				...validCarousel,
				content: { ...validCarousel.content, slides: [] },
			}).success
		).toBe(false);
	});

	it('validates badge metadata and product assignments', () => {
		expect(
			createBadgeSchema.safeParse({
				color: '#2563EB',
				icon: 'verified',
				name: 'Destaque',
				storeId: 'store-1',
			}).success
		).toBe(true);
		expect(
			createBadgeSchema.safeParse({
				color: 'blue',
				name: 'Destaque',
				storeId: 'store-1',
			}).success
		).toBe(false);
		expect(
			setBadgeProductsSchema.safeParse({ productIds: ['product-1', 'product-2'] }).success
		).toBe(true);
	});

	it('validates default shipping updates', () => {
		expect(
			updateDefaultShippingSchema.safeParse({
				shippingTime: 45,
				storeId: 'store-1',
				value: 7.5,
			}).success
		).toBe(true);
		expect(
			updateDefaultShippingSchema.safeParse({
				shippingTime: -1,
				storeId: 'store-1',
				value: -5,
			}).success
		).toBe(false);
	});

	it('defaults neighborhood delivery blocking to disabled', () => {
		const result = upsertNeighborhoodShippingSchema.parse({
			mode: 'DEFAULT',
			neighborhood: 'Centro',
			storeId: 'store-1',
		});

		expect(result.isBlocked).toBe(false);
		expect(
			upsertNeighborhoodShippingSchema.parse({
				...result,
				isBlocked: true,
			}).isBlocked
		).toBe(true);
	});

	it('formats zod errors as api errors', () => {
		const result = loginUserSchema.safeParse({
			email: 'invalid-email',
			password: '',
		});

		expect(result.success).toBe(false);

		if (!result.success) {
			expect(formatZodError(result.error)).toMatchObject({
				code: 'VALIDATION_ERROR',
				statusCode: 400,
			});
		}
	});

	it('validates supported theme names', () => {
		expect(themeNameSchema.safeParse('default').success).toBe(true);
		expect(themeNameSchema.safeParse('cruzeiro').success).toBe(true);
		expect(themeNameSchema.safeParse('dark').success).toBe(false);
	});

	it('validates declarative user group rules and keeps manual groups compatible', () => {
		const manualGroup = createUserGroupSchema.parse({ name: 'Clientes recorrentes' });
		expect(manualGroup).toMatchObject({
			mode: UserGroupMode.MANUAL,
			rules: [],
			userIds: [],
		});

		expect(
			createUserGroupSchema.safeParse({
				mode: UserGroupMode.RULE,
				name: 'Clientes premium',
				rules: [],
			}).success
		).toBe(false);

		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{
						field: 'gender',
						operator: UserGroupRuleOperator.EQUAL,
						source: UserGroupRuleSource.USER,
						value: 'MALE',
					},
					{
						field: 'total',
						logicalOperator: UserGroupLogicalOperator.AND,
						operator: UserGroupRuleOperator.GREATER_THAN_OR_EQUAL,
						source: UserGroupRuleSource.ORDER,
						value: 100,
					},
				],
			}).success
		).toBe(true);
	});

	it('rejects arbitrary fields and missing logical operators in user group rules', () => {
		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{
						field: 'password',
						operator: '==',
						source: 'user',
						value: 'secret',
					},
				],
			}).success
		).toBe(false);

		expect(
			searchUserGroupUsersSchema.safeParse({
				rules: [
					{ field: 'name', operator: '==', source: 'user', value: 'Ana' },
					{ field: 'status', operator: '==', source: 'order', value: 'DELIVERED' },
				],
			}).success
		).toBe(false);
	});

	it('validates automatic WhatsApp message configurations', () => {
		expect(
			createWhatsAppMessageConfigurationSchema.safeParse({
				location: WhatsAppMessageLocation.PREPARING,
				operation: WhatsAppMessageOperation.ENTRY,
				template: {
					html: '<p>Olá &lt;nome&gt;</p>',
					version: 1,
				},
			}).success
		).toBe(true);

		expect(
			createWhatsAppMessageConfigurationSchema.safeParse({
				location: 'PREPARING',
				operation: 'DURING',
				template: { html: '', version: 1 },
			}).success
		).toBe(false);
	});

	it('validates printer configuration and normalized assignments', () => {
		expect(createPrinterConfigurationSchema.safeParse({
			storeId: 'store-1',
			connectionId: 'webserial:123:456:0',
			name: 'Cozinha',
			connectionStatus: PrinterConnectionStatus.CONNECTED,
		}).success).toBe(true);
		expect(setPrinterAssignmentsSchema.safeParse({
			categoryIds: ['category-1'],
			subcategoryIds: ['subcategory-1'],
		}).success).toBe(true);
		expect(createPrinterConfigurationSchema.safeParse({
			storeId: 'store-1',
			connectionId: '',
			name: '',
		}).success).toBe(false);
	});
});
