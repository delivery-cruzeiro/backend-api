export * from './printer-contracts.js';
export * from './password-recovery.js';
import type { PrinterOperationalConfiguration } from './printer-contracts.js';
import { PRINTER_RECEIPT_SECTIONS, type PrinterReceiptSection } from './printer-contracts.js';
import { z } from 'zod';
import { USER_AVATAR_IDS } from './user-avatar.js';
export * from './user-avatar.js';

// ============================================================================
// ENUMS
// ============================================================================

export const UserRole = {
	CLIENT: 1,
	ADMIN: 2,
	MANAGER: 3,
	SUPER_ADMIN: 4,
} as const;
export type UserRole = number;

export function hasRole(role: unknown, minimumRole: UserRole): role is UserRole {
	return (
		typeof role === 'number' &&
		Number.isSafeInteger(role) &&
		role >= minimumRole &&
		minimumRole >= UserRole.CLIENT
	);
}

export function canAccessAdmin(role: unknown): role is UserRole {
	return hasRole(role, UserRole.ADMIN);
}

export enum UserGender {
	FEMALE = 'FEMALE',
	MALE = 'MALE',
	NON_BINARY = 'NON_BINARY',
	OTHER = 'OTHER',
	PREFER_NOT_TO_SAY = 'PREFER_NOT_TO_SAY',
}

export enum UserGroupMode {
	MANUAL = 'MANUAL',
	RULE = 'RULE',
}

export enum UserGroupRuleSource {
	USER = 'user',
	ORDER = 'order',
	ITEM = 'item',
	PRESET = 'preset',
}

export enum UserGroupRulePreset {
	FIRST_ORDER = 'first_order',
	REGULAR_CUSTOMER_10_ORDERS = 'regular_customer_10_orders',
}

export enum UserGroupRuleOperator {
	LESS_THAN = '<',
	LESS_THAN_OR_EQUAL = '<=',
	EQUAL = '==',
	GREATER_THAN_OR_EQUAL = '>=',
	GREATER_THAN = '>',
}

export enum UserGroupLogicalOperator {
	AND = 'AND',
	OR = 'OR',
}

export const userGroupUserRuleFields = [
	'name',
	'email',
	'phone',
	'avatar',
	'role',
	'isActive',
	'createdAt',
	'updatedAt',
	'emailVerified',
	'gender',
] as const;

export const userGroupOrderRuleFields = [
	'paymentMethodId',
	'addressId',
	'status',
	'subtotal',
	'deliveryFee',
	'discount',
	'total',
	'estimatedDelivery',
	'deliveredAt',
	'createdAt',
	'updatedAt',
	'orderNumber',
	'store_id',
	'promotion_id',
] as const;

export const userGroupItemRuleFields = ['orderId', 'productId', 'quantity', 'price'] as const;

export type UserGroupUserRuleField = (typeof userGroupUserRuleFields)[number];
export type UserGroupOrderRuleField = (typeof userGroupOrderRuleFields)[number];
export type UserGroupItemRuleField = (typeof userGroupItemRuleFields)[number];

export enum OrderStatus {
	PENDING = 'PENDING',
	CONFIRMED = 'CONFIRMED',
	PREPARING = 'PREPARING',
	ON_THE_WAY = 'ON_THE_WAY',
	DELIVERED = 'DELIVERED',
	CANCELLED = 'CANCELLED',
}

export enum PaymentStatus {
	PENDING = 'PENDING',
	PROCESSING = 'PROCESSING',
	COMPLETED = 'COMPLETED',
	FAILED = 'FAILED',
	REFUNDED = 'REFUNDED',
}

export enum PromotionType {
	PERCENTAGE = 'PERCENTAGE',
	FIXED_AMOUNT = 'FIXED_AMOUNT',
	BUY_X_GET_Y = 'BUY_X_GET_Y',
}

export enum PromotionEligibilityType {
	ALL = 'ALL',
	GROUP = 'GROUP',
	SINGLE_USER = 'SINGLE_USER',
}

export enum PromotionUsageMode {
	USAGE_QUANTITY = 'USAGE_QUANTITY',
	AVAILABLE_PERIOD = 'AVAILABLE_PERIOD',
}

export enum ProductAdditionalFieldType {
	MULTI_OPTION = 'MULTI_OPTION',
	COMBOBOX = 'COMBOBOX',
	CHECKBOX = 'CHECKBOX',
	TEXT = 'TEXT',
	RADIO = 'RADIO',
}

export enum CarouselTransition {
	FADE = 'FADE',
	SLIDE = 'SLIDE',
	ZOOM = 'ZOOM',
	NONE = 'NONE',
}

export enum CarouselSize {
	SMALL = 'SMALL',
	MEDIUM = 'MEDIUM',
	LARGE = 'LARGE',
}

export enum PaymentType {
	CUSTOM = 'CUSTOM',
	CREDIT_CARD = 'CREDIT_CARD',
	DEBIT_CARD = 'DEBIT_CARD',
	PIX = 'PIX',
	CASH = 'CASH',
}

export enum PaymentCardType {
	CREDIT = 'CREDIT',
	DEBIT = 'DEBIT',
}

export enum ShippingChargeMode {
	DEFAULT = 'DEFAULT',
	MANUAL = 'MANUAL',
	TEMPLATE = 'TEMPLATE',
}

export enum SystemLayout {
	QUIET_OPS = 'QUIET_OPS',
	MOTION_CANVAS = 'MOTION_CANVAS',
	CRAVE_MARKET = 'CRAVE_MARKET',
}

export const CAROUSEL_SIZE_LABELS: Record<CarouselSize, string> = {
	SMALL: 'Pequeno',
	MEDIUM: 'Médio',
	LARGE: 'Grande',
};

/** One presentation per carousel, shared by its slides and the admin preview. */
export function getCarouselPresentation(layout: SystemLayout, size?: CarouselSize) {
	const defaultSize =
		layout === SystemLayout.CRAVE_MARKET ? CarouselSize.LARGE : CarouselSize.MEDIUM;
	const resolvedSize = size ?? defaultSize;
	const presets = {
		[SystemLayout.CRAVE_MARKET]: {
			SMALL: { height: 'clamp(96px, 10vw, 192px)', desktopHeight: 192 },
			MEDIUM: { height: 'clamp(140px, 15vw, 288px)', desktopHeight: 288 },
			LARGE: { height: 'clamp(180px, 20vw, 384px)', desktopHeight: 384 },
		},
		[SystemLayout.MOTION_CANVAS]: {
			SMALL: { height: 'clamp(112px, 9vw, 144px)', desktopHeight: 144 },
			MEDIUM: { height: 'clamp(180px, 14vw, 220px)', desktopHeight: 220 },
			LARGE: { height: 'clamp(240px, 22vw, 352px)', desktopHeight: 352 },
		},
		[SystemLayout.QUIET_OPS]: {
			SMALL: { height: 'clamp(96px, 8vw, 128px)', desktopHeight: 128 },
			MEDIUM: { height: 'clamp(180px, 14vw, 220px)', desktopHeight: 220 },
			LARGE: { height: 'clamp(224px, 20vw, 320px)', desktopHeight: 320 },
		},
	};
	const preset = presets[layout][resolvedSize];
	// Full HD viewport: account for the theme's sidebar, margins and maximum width.
	const imageWidth =
		layout === SystemLayout.CRAVE_MARKET
			? 1920
			: layout === SystemLayout.MOTION_CANVAS
				? 1624
				: 1472;
	return {
		...preset,
		defaultSize,
		size: resolvedSize,
		imageWidth,
		imageHeight: preset.desktopHeight,
	};
}

export enum WhatsAppConnectionStatus {
	DISCONNECTED = 'DISCONNECTED',
	CONNECTING = 'CONNECTING',
	WAITING_QR_CODE = 'WAITING_QR_CODE',
	CONNECTED = 'CONNECTED',
	ERROR = 'ERROR',
}

export enum PrinterConnectionStatus {
	CONNECTED = 'CONNECTED',
	DISCONNECTED = 'DISCONNECTED',
	ERROR = 'ERROR',
}

export enum WhatsAppMessageLocation {
	PIX_ONLINE = 'PIX_ONLINE',
	PENDING = 'PENDING',
	CONFIRMED = 'CONFIRMED',
	PREPARING = 'PREPARING',
	ON_THE_WAY = 'ON_THE_WAY',
}

export enum WhatsAppMessageOperation {
	ENTRY = 'ENTRY',
	EXIT = 'EXIT',
}

export const whatsappMessagePlaceholderKeys = [
	'formaPagamento',
	'nome',
	'numeroPedido',
	'telefone',
	'endereco',
	'nomeLoja',
	'statusPedido',
	'totalPedido',
	'itensPedido',
] as const;

export type WhatsAppMessagePlaceholderKey = (typeof whatsappMessagePlaceholderKeys)[number];

export interface WhatsAppMessageTemplateDTO {
	version: 1;
	html: string;
}

export interface WhatsAppStatusDTO {
	connected: boolean;
	status: WhatsAppConnectionStatus;
	phone?: string;
	name?: string;
}

export interface WhatsAppQrCodeDTO {
	mimeType: 'image/png';
	data: string;
}

export enum NotificationType {
	ORDER_CONFIRMED = 'ORDER_CONFIRMED',
	ORDER_PREPARING = 'ORDER_PREPARING',
	ORDER_ON_THE_WAY = 'ORDER_ON_THE_WAY',
	ORDER_DELIVERED = 'ORDER_DELIVERED',
	ORDER_CANCELLED = 'ORDER_CANCELLED',
	PROMOTION = 'PROMOTION',
	SYSTEM = 'SYSTEM',
}

export enum PointType {
	EARNED = 'EARNED',
	REDEEMED = 'REDEEMED',
}

export const themeNames = ['default', 'cruzeiro'] as const;
export type ThemeName = (typeof themeNames)[number];

export type DeliveryModuleKey =
	'admin' | 'attendance' | 'crm' | 'delivery' | 'fiscal' | 'pdv' | 'promotions';

export interface BrandAssetConfig {
	faviconUrl?: string;
	logoAlt: string;
	logoUrl?: string;
}

export interface BrandThemeConfig {
	name: ThemeName;
	tokens: Record<string, string>;
}

export interface BrandI18nConfig {
	defaultLocale: 'pt-BR' | 'en';
	overrides: Record<string, Record<string, string>>;
}

export interface AppBrandConfig {
	assets: BrandAssetConfig;
	brandName: string;
	companyName: string;
	i18n: BrandI18nConfig;
	modules: Record<DeliveryModuleKey, boolean>;
	publicName: string;
	theme: BrandThemeConfig;
}

// ============================================================================
// SHARED SCHEMAS
// ============================================================================

const cuidSchema = z.string().min(1);
const moneySchema = z.number().nonnegative();
const optionalTextSchema = z.string().trim().min(1).optional();
const storeIdsSchema = z.array(cuidSchema).min(1);

export const themeNameSchema = z.enum(themeNames);

// Customer profiles accept formatted numbers. Local 10/11-digit numbers use Brazil's DDI.
// An explicit + or 00 preserves the caller's country code; letters/extensions are rejected.
export const whatsAppPhoneSchema = z
	.string()
	.trim()
	.max(64)
	.regex(/^\+?[\d\s().-]+$/)
	.transform(phone => {
		const compact = phone.replace(/[\s().-]/g, '');
		if (compact.startsWith('+')) return compact.slice(1);
		if (compact.startsWith('00')) return compact.slice(2);
		return compact.length === 10 || compact.length === 11 ? `55${compact}` : compact;
	})
	.pipe(
		z
			.string()
			.regex(/^[1-9]\d{9,14}$/, 'Informe um telefone válido com DDD ou código internacional.')
	);

export const sendWhatsAppTextSchema = z.object({
	phone: whatsAppPhoneSchema,
	message: z.string().trim().min(1).max(4096),
});

export const whatsappMessageTemplateSchema = z.object({
	version: z.literal(1),
	html: z.string().trim().min(1).max(20_000),
});

export const createWhatsAppMessageConfigurationSchema = z.object({
	location: z.enum(WhatsAppMessageLocation),
	operation: z.enum(WhatsAppMessageOperation),
	paymentMethodId: cuidSchema.nullable().optional(),
	template: whatsappMessageTemplateSchema,
	isActive: z.boolean().optional().default(true),
});

export const updateWhatsAppMessageConfigurationSchema = createWhatsAppMessageConfigurationSchema
	.partial()
	.refine(configuration => Object.keys(configuration).length > 0, {
		message: 'at least one field is required',
	});

export * from './printer-layout.js';
import { printerReceiptLayoutSchema } from './printer-layout.js';
import type { PrinterReceiptLayout } from './printer-layout.js';
const windowsPrinterFields = {
	windowsQueueId: z.string().trim().min(1).max(255).nullable().optional(),
	windowsQueueName: z.string().trim().min(1).max(260).nullable().optional(),
	windowsDriverName: z.string().trim().min(1).max(260).nullable().optional(),
	windowsPortName: z.string().max(512).nullable().optional(),
	windowsPrintProcessor: z.string().max(260).nullable().optional(),
	windowsDataType: z.string().max(80).nullable().optional(),
	windowsCapabilities: z
		.object({
			raw: z.boolean(),
			color: z.boolean().optional(),
			duplex: z.boolean().optional(),
			paperSizes: z.array(z.string().max(100)).max(100).optional(),
		})
		.nullable()
		.optional(),
	bridgeInstallationId: z.string().max(255).nullable().optional(),
};
const printerOperationalFields = {
	...windowsPrinterFields,
	adapterId: z.enum(['esc-pos', 'daruma-dr700', 'generic']).optional(),
	columns: z.number().int().min(16).max(128).optional(),
	encoding: z.enum(['cp850', 'latin1', 'ascii']).optional(),
	autoCut: z.boolean().optional(),
	copies: z.number().int().min(1).max(10).optional(),
	lastSeenAt: z.iso.datetime().nullable().optional(),
	lastKnownStatus: z
		.enum([
			'READY',
			'OFFLINE',
			'ERROR',
			'UNKNOWN',
			'MISSING',
			'CHANGED',
			'INCOMPATIBLE',
			'UNAVAILABLE',
		])
		.nullable()
		.optional(),
};
function validPrinterConfiguration(value: {
	transport?: string;
	adapterId?: string;
	autoCut?: boolean;
	windowsCapabilities?: { raw: boolean } | null;
	[key: string]: unknown;
}) {
	if (value.transport !== 'WINDOWS_BRIDGE')
		return Object.keys(windowsPrinterFields).every(key => value[key] == null);
	return Boolean(
		value.windowsQueueId &&
		value.windowsQueueName &&
		value.windowsDriverName &&
		value.windowsCapabilities?.raw &&
		value.adapterId &&
		value.columns &&
		value.encoding &&
		typeof value.autoCut === 'boolean' &&
		value.copies &&
		!(value.adapterId === 'generic' && value.autoCut)
	);
}
export const createPrinterConfigurationSchema = z
	.object({
		storeId: cuidSchema,
		connectionId: z.string().trim().min(1).max(255),
		name: z.string().trim().min(1).max(80),
		connectionStatus: z
			.enum(PrinterConnectionStatus)
			.optional()
			.default(PrinterConnectionStatus.CONNECTED),
		transport: z.enum(['WEB_SERIAL', 'WINDOWS_BRIDGE']).optional(),
		...printerOperationalFields,
	})
	.refine(validPrinterConfiguration, {
		message: 'Configuração incompatível com o transporte ou protocolo da impressora',
	});
export const updatePrinterConfigurationSchema = z
	.object({
		name: z.string().trim().min(1).max(80).optional(),
		isPrimary: z.boolean().optional(),
		connectionStatus: z.enum(PrinterConnectionStatus).optional(),
		...printerOperationalFields,
	})
	.refine(configuration => Object.keys(configuration).length > 0, {
		message: 'at least one field is required',
	});
export const setPrinterAssignmentsSchema = z.object({
	receiptLayout: printerReceiptLayoutSchema.optional(),
	receiptSections: z.array(z.enum(PRINTER_RECEIPT_SECTIONS)).max(5).optional(),
	categoryIds: z.array(cuidSchema).max(1000).default([]),
	subcategoryIds: z.array(cuidSchema).max(1000).default([]),
});

export const cpfSchema = z
	.string()
	.trim()
	.refine(value => /^[\d.\-\s]+$/.test(value), 'CPF inválido')
	.transform(value => value.replace(/\D/g, ''))
	.refine(value => {
		if (!/^\d{11}$/.test(value) || /^(\d)\1{10}$/.test(value)) return false;
		for (let length = 9; length <= 10; length++) {
			const sum = [...value.slice(0, length)].reduce(
				(total, digit, index) => total + Number(digit) * (length + 1 - index),
				0
			);
			const digit = (sum * 10) % 11;
			if ((digit === 10 ? 0 : digit) !== Number(value[length])) return false;
		}
		return true;
	}, 'CPF inválido');

export const registerUserSchema = z.object({
	cpf: cpfSchema.nullable().optional(),
	email: z.email(),
	password: z.string().min(8),
	name: z.string().trim().min(1),
	phone: z.string().trim().min(1, 'Telefone obrigatório'),
});

export const loginUserSchema = z.object({
	email: z.email(),
	password: z.string().min(1),
});

export const createUserSchema = registerUserSchema
	.extend({
		role: z
			.number()
			.int()
			.min(UserRole.CLIENT)
			.max(2147483647)
			.optional()
			.default(UserRole.CLIENT),
		storeIds: storeIdsSchema.optional(),
	})
	.superRefine((user, context) => {
		const storeIds = user.storeIds ?? [];

		if (user.role === UserRole.CLIENT && storeIds.length > 0) {
			context.addIssue({
				code: 'custom',
				message: 'clients cannot have stores',
				path: ['storeIds'],
			});
		}

		if (user.role !== UserRole.CLIENT && storeIds.length === 0) {
			context.addIssue({
				code: 'custom',
				message: 'storeIds is required for non-client users',
				path: ['storeIds'],
			});
		}
	});

export const updateUserSchema = z.object({
	cpf: cpfSchema.nullable().optional(),
	email: z.email().optional(),
	name: optionalTextSchema,
	gender: z.enum(UserGender).nullable().optional(),
	phone: optionalTextSchema,
	avatar: z.enum(USER_AVATAR_IDS).nullable().optional(),
	role: z.number().int().min(UserRole.CLIENT).max(2147483647).optional(),
	isActive: z.boolean().optional(),
	storeIds: storeIdsSchema.optional(),
});

export const createAddressSchema = z.object({
	street: z.string().trim().min(1),
	number: z.string().trim().min(1),
	complement: optionalTextSchema,
	neighborhood: z.string().trim().min(1),

	city: z.string().trim().min(1),
	state: z.string().trim().min(2).max(2),
	zipCode: z.string().trim().min(8),
	latitude: z.number().optional(),
	longitude: z.number().optional(),
	isDefault: z.boolean().optional(),
});

export const updateAddressSchema = createAddressSchema.partial();

export const createStoreBusinessHourSchema = z.object({
	weekDay: z.number().int().min(0).max(6).nullable().optional(),
	date: z.coerce.date().nullable().optional(),
	openTime: optionalTextSchema.nullable(),
	closeTime: optionalTextSchema.nullable(),
	isClosed: z.boolean().optional(),
});

export const createStoreSchema = z.object({
	name: z.string().trim().min(1),
	nickname: z.string().trim().min(1),
	isActive: z.boolean().optional(),
	phoneNumber: optionalTextSchema.nullable(),
	openHour: optionalTextSchema.nullable(),
	closeHour: optionalTextSchema.nullable(),
	weekDaysOpen: z.array(z.number().int().min(0).max(6)).nullable().optional(),
	addressId: cuidSchema,
	ownerId: cuidSchema,
	cnpj: optionalTextSchema.nullable(),
	businessHours: z.array(createStoreBusinessHourSchema).optional(),
});

export const updateStoreSchema = createStoreSchema.partial();

const additionalQuantitySchema = z.number().int().min(0).max(999);
export const additionalQuantityOptionSchema = z.object({
	id: z.string().trim().min(1),
	label: z.string().trim().min(1),
	additionalValue: moneySchema.max(999.99).optional(),
	minQuantity: additionalQuantitySchema.optional(),
	maxQuantity: additionalQuantitySchema.optional(),
});

export const productAdditionalFieldSchema = z
	.object({
		additionalValue: moneySchema.max(999.99).optional(),
		id: z.string().trim().min(1),
		label: z.string().trim().min(1),
		required: z.boolean().optional(),
		minQuantity: additionalQuantitySchema.optional(),
		maxQuantity: additionalQuantitySchema.optional(),
		quantityOptions: z.array(additionalQuantityOptionSchema).max(100).optional(),
		options: z.array(z.string().trim().min(1)).optional().default([]),
		type: z.enum(ProductAdditionalFieldType),
	})
	.superRefine((field, context) => {
		const issue = (message: string, path: (string | number)[]) =>
			context.addIssue({ code: 'custom', message, path });
		if (field.type === ProductAdditionalFieldType.MULTI_OPTION) {
			const options = field.quantityOptions ?? [];
			if (!options.length) issue('Adicione pelo menos uma opção.', ['quantityOptions']);
			if (field.options.length || field.additionalValue !== undefined)
				issue('O valor adicional pertence a cada opção.', ['additionalValue']);
			if (new Set(options.map(option => option.id)).size !== options.length)
				issue('Identificadores de opções duplicados.', ['quantityOptions']);
			if (
				field.minQuantity !== undefined &&
				field.maxQuantity !== undefined &&
				field.minQuantity > field.maxQuantity
			)
				issue('O mínimo geral não pode superar o máximo.', ['minQuantity']);
			if (field.required && field.maxQuantity === 0)
				issue('Um campo obrigatório deve permitir pelo menos um item.', ['maxQuantity']);
			options.forEach((option, index) => {
				if (
					field.minQuantity !== undefined &&
					option.minQuantity !== undefined &&
					option.minQuantity > field.minQuantity
				)
					issue('O mínimo da opção não pode superar o mínimo geral.', [
						'quantityOptions',
						index,
						'minQuantity',
					]);
				if ((option.minQuantity ?? 0) > (option.maxQuantity ?? 999))
					issue('O mínimo da opção não pode superar o máximo.', [
						'quantityOptions',
						index,
						'minQuantity',
					]);
				if (
					field.maxQuantity !== undefined &&
					((option.minQuantity ?? 0) > field.maxQuantity ||
						(option.maxQuantity !== undefined &&
							option.maxQuantity > field.maxQuantity))
				)
					issue('Os limites da opção não podem superar o máximo geral.', [
						'quantityOptions',
						index,
						'maxQuantity',
					]);
			});
			const minimum = options.reduce((sum, option) => sum + (option.minQuantity ?? 0), 0);
			if (field.maxQuantity !== undefined && minimum > field.maxQuantity)
				issue('A soma dos mínimos supera o máximo geral.', ['quantityOptions']);
			const capacity = options.reduce((sum, option) => sum + (option.maxQuantity ?? 999), 0);
			if (capacity < Math.max(field.minQuantity ?? 0, field.required ? 1 : 0))
				issue('As opções não permitem alcançar o mínimo geral.', ['minQuantity']);
			return;
		}
		if (
			field.quantityOptions?.length ||
			field.minQuantity !== undefined ||
			field.maxQuantity !== undefined
		)
			issue('Limites de quantidade pertencem ao campo multiopcional.', ['quantityOptions']);
		const needsOptions =
			field.type === ProductAdditionalFieldType.COMBOBOX ||
			field.type === ProductAdditionalFieldType.RADIO;

		if (needsOptions && field.options.length === 0) {
			context.addIssue({
				code: 'custom',
				message: 'options are required for combobox and radio fields',
				path: ['options'],
			});
		}

		if (!needsOptions && field.options.length > 0) {
			context.addIssue({
				code: 'custom',
				message: 'options are only allowed for combobox and radio fields',
				path: ['options'],
			});
		}
	});

export enum ProductAdditionalFieldSource {
	CATEGORY = 'CATEGORY',
	PRODUCT = 'PRODUCT',
	SUBCATEGORY = 'SUBCATEGORY',
}

export const effectiveProductAdditionalFieldSchema = productAdditionalFieldSchema.safeExtend({
	definitionId: z.string().trim().min(1),
	source: z.enum(ProductAdditionalFieldSource),
	sourceId: z.string().trim().min(1),
});

export const imageReferencesSchema = z.array(z.url().refine(value => value.startsWith('https://'), 'Use um link HTTPS')).max(100).refine(urls => new Set(urls).size === urls.length, 'Imagens duplicadas');

export const createCategorySchema = z.object({
	additionalFields: z.array(productAdditionalFieldSchema).optional().default([]),
	name: z.string().trim().min(1),
	description: optionalTextSchema,
	imageUrl: z.url().optional(),
	imageUrls: imageReferencesSchema.optional(),
	order: z.number().int().nonnegative().optional(),
	isActive: z.boolean().optional(),
	storeIds: storeIdsSchema,
});

export const updateCategorySchema = createCategorySchema.partial().extend({
	additionalFields: z.array(productAdditionalFieldSchema).optional(),
});

export const createSubcategorySchema = createCategorySchema.extend({
	categoryId: cuidSchema,
});

export const updateSubcategorySchema = createSubcategorySchema.partial().extend({
	additionalFields: z.array(productAdditionalFieldSchema).optional(),
});

export const createMenuSchema = createCategorySchema.omit({ additionalFields: true, imageUrls: true }).extend({
	categoryIds: z.array(cuidSchema).optional(),
	subcategoryIds: z.array(cuidSchema).optional(),
});

export const updateMenuSchema = createMenuSchema.partial();

export const productAdditionalFieldValueSchema = z.object({
	additionalValue: moneySchema.optional(),
	fieldId: z.string().trim().min(1),
	label: z.string().trim().min(1),
	type: z.enum(ProductAdditionalFieldType),
	value: z.union([
		z.string(),
		z.boolean(),
		z
			.array(
				z.object({
					optionId: z.string().trim().min(1),
					quantity: additionalQuantitySchema,
					label: z.string().optional(),
				})
			)
			.max(100),
	]),
});

export const productPricingModeSchema = z.enum(['FIXED', 'ADDITIVE']);
export type ProductPricingMode = z.infer<typeof productPricingModeSchema>;

// Work in cents so the minimum is checked per unit without floating point drift.
export function calculateProductPrice(
	price: number,
	additionalValue: number,
	pricingMode: string = 'FIXED'
) {
	const minimum = Math.round(price * 100);
	const additions = Math.round(additionalValue * 100);
	return {
		unitPrice: (additions + (pricingMode === 'ADDITIVE' ? 0 : minimum)) / 100,
		meetsMinimum: pricingMode !== 'ADDITIVE' || additions >= minimum,
	};
}

export const createProductSchema = z.object({
	pricingMode: productPricingModeSchema.optional().default('FIXED'),
	badgeIds: z.array(cuidSchema).optional().default([]),
	categoryId: cuidSchema,
	subcategoryId: cuidSchema.nullable().optional(),
	name: z.string().trim().min(1),
	description: z.string().trim().min(1),
	price: moneySchema,
	imageUrl: z.url().optional(),
	imageUrls: imageReferencesSchema.optional(),
	additionalFields: z.array(productAdditionalFieldSchema).optional().default([]),
	unavailable: z.boolean().optional().default(false),
	isActive: z.boolean().optional(),
	order: z.number().int().nonnegative().optional(),
	storeIds: storeIdsSchema,
});

export const updateProductSchema = createProductSchema.partial().extend({
	badgeIds: z.array(cuidSchema).optional(),
	additionalFields: z.array(productAdditionalFieldSchema).optional(),
	unavailable: z.boolean().optional(),
	pricingMode: productPricingModeSchema.optional(),
});

export const createBadgeSchema = z.object({
	color: z.string().regex(/^#[0-9a-f]{6}$/i, 'color must use the #RRGGBB format'),
	icon: z.string().trim().min(1).max(80).nullable().optional(),
	isActive: z.boolean().optional().default(true),
	name: z.string().trim().min(1).max(80),
	storeId: cuidSchema,
});

export const updateBadgeSchema = createBadgeSchema.omit({ storeId: true }).partial();

export const setBadgeProductsSchema = z.object({
	productIds: z.array(cuidSchema).max(1000),
});

export const carouselSlideSchema = z.object({
	html: z.string().max(20_000).optional().default(''),
	imageUrl: z.url().optional(),
});

export const carouselContentSchema = z.object({
	size: z.enum(CarouselSize).optional(),
	durationSeconds: z.number().int().min(1).max(300),
	transition: z.enum(CarouselTransition),
	slides: z.array(carouselSlideSchema).min(1).max(20),
});

export const createCarouselSchema = z.object({
	name: z.string().trim().min(1).max(120),
	storeId: cuidSchema,
	content: carouselContentSchema,
});

export const updateCarouselSchema = createCarouselSchema
	.omit({ storeId: true })
	.partial()
	.refine(input => Object.keys(input).length > 0, 'at least one field is required');

export const activateCarouselSchema = z.object({
	id: cuidSchema,
});

export const cartItemSchema = z.object({
	cartItemId: z.string().trim().min(1).optional(),
	productId: cuidSchema,
	productName: z.string().trim().min(1),
	productPrice: moneySchema,
	pricingMode: productPricingModeSchema.optional(),
	quantity: z.number().int().positive(),
	imageUrl: z.url().optional(),
	notes: optionalTextSchema,
	additionalFieldValues: z.array(productAdditionalFieldValueSchema).optional(),
});

export const cartSchema = z.object({
	items: z.array(cartItemSchema),
	subtotal: moneySchema,
	deliveryFee: moneySchema,
	discount: moneySchema,
	total: moneySchema,
});

export const createOrderItemSchema = z.object({
	additionalFieldValues: z.array(productAdditionalFieldValueSchema).optional().default([]),
	productId: cuidSchema,
	quantity: z.number().int().positive(),
	notes: optionalTextSchema,
});

export const createOrderSchema = z.object({
	userId: cuidSchema.optional(),
	addressId: cuidSchema.optional().nullable(),
	paymentMethodId: cuidSchema.optional(),
	storeId: cuidSchema,
	items: z.array(createOrderItemSchema).min(1),
	notes: optionalTextSchema,
});

export const updateOrderStatusSchema = z.object({
	status: z.enum(OrderStatus),
});

export const listAdminOrdersQuerySchema = z.object({
	status: z.union([z.enum(OrderStatus), z.literal('ALL')]).optional(),
	storeId: cuidSchema.optional(),
});

export const updateAdminOrderStatusSchema = updateOrderStatusSchema;

const adminPaginationSchema = z.object({
	page: z.coerce.number().int().min(1).max(1000000).default(1),
	pageSize: z.coerce
		.number()
		.pipe(z.union([z.literal(10), z.literal(30), z.literal(50)]))
		.default(10),
});

const customerSearchText = z.string().trim().min(1).max(200).optional();

export const adminCustomerSearchSchema = adminPaginationSchema.extend({
	id: customerSearchText,
	name: customerSearchText,
	email: customerSearchText,
	cpf: z.string().trim().max(24).regex(/^[\d.\-\s]+$/)
		.transform(value => value.replace(/\D/g, ''))
		.pipe(z.string().min(3).max(11)).optional(),
	phone: z.string().trim().max(32).regex(/^[\d+().\-\s]+$/)
		.transform(value => value.replace(/\D/g, ''))
		.pipe(z.string().min(3).max(15)).optional(),
	gender: z.enum(UserGender).nullable().optional(),
	avatar: z.union([z.enum(['present', 'absent']), z.enum(USER_AVATAR_IDS)]).optional(),
	isActive: z.boolean().optional(),
	emailVerified: z.boolean().optional(),
	createdFrom: z.iso.date().optional(),
	createdTo: z.iso.date().optional(),
	updatedFrom: z.iso.date().optional(),
	updatedTo: z.iso.date().optional(),
}).refine(q => !q.createdFrom || !q.createdTo || q.createdFrom <= q.createdTo, {
	message: 'A data inicial de cadastro deve ser anterior ou igual à final',
	path: ['createdTo'],
}).refine(q => !q.updatedFrom || !q.updatedTo || q.updatedFrom <= q.updatedTo, {
	message: 'A data inicial de atualização deve ser anterior ou igual à final',
	path: ['updatedTo'],
});

export type AdminCustomerSearchDTO = z.infer<typeof adminCustomerSearchSchema>;
export type AdminPageSize = AdminCustomerSearchDTO['pageSize'];

export interface AdminCustomerDTO {
	id: string;
	name: string;
	email: string;
	cpf: string | null;
	phone: string | null;
	gender: UserGender | null;
	avatar: string | null;
	role: typeof UserRole.CLIENT;
	isActive: boolean;
	emailVerified: boolean;
	createdAt: string;
	updatedAt: string;
}

export interface AdminCustomerSearchResponse {
	customers: AdminCustomerDTO[];
	total: number;
	page: number;
	pageSize: AdminPageSize;
	totalPages: number;
}

export const adminOrderHistoryQuerySchema = listAdminOrdersQuerySchema
	.extend(adminPaginationSchema.shape)
	.extend({
		startDate: z.iso.date().optional(),
		endDate: z.iso.date().optional(),
		customerId: customerSearchText,
		customerName: z.string().trim().min(1).max(200).optional(),
		orderNumber: z.coerce.number().int().positive().max(2147483647).optional(),
		minTotal: z.coerce.number().finite().nonnegative().optional(),
		maxTotal: z.coerce.number().finite().nonnegative().optional(),
	})
	.refine(q => !q.startDate || !q.endDate || q.startDate <= q.endDate, {
		message: 'A data inicial deve ser anterior ou igual à data final',
		path: ['endDate'],
	})
	.refine(q => q.minTotal === undefined || q.maxTotal === undefined || q.minTotal <= q.maxTotal, {
		message: 'O valor mínimo deve ser menor ou igual ao máximo',
		path: ['maxTotal'],
	});

export type AdminOrderHistoryQueryDTO = z.infer<typeof adminOrderHistoryQuerySchema>;

export const createPaymentMethodSchema = z.object({
	userId: cuidSchema,
	type: z.enum(PaymentType),
	cardType: z.enum(PaymentCardType).nullable().optional(),
	provider: z.string().trim().min(1),
	providerId: z.string().trim().min(1),
	last4: z.string().length(4).optional(),
	expiryMonth: z.number().int().min(1).max(12).optional(),
	expiryYear: z.number().int().min(2024).optional(),
	cardHolder: optionalTextSchema,
	isDefault: z.boolean().optional(),
});

export const updateClientProfileSchema = z.object({
	name: z.string().trim().min(1),
	gender: z.enum(UserGender).nullable().optional(),
	phone: optionalTextSchema.nullable(),
	avatar: z.enum(USER_AVATAR_IDS).nullable().optional(),
});

export const createClientAddressSchema = createAddressSchema;
export const updateClientAddressSchema = createClientAddressSchema.partial();

export const createClientPaymentMethodSchema = z.object({
	cardType: z.enum(PaymentCardType),
	provider: z.string().trim().min(1),
	providerId: z.string().trim().min(1),
	last4: z.string().length(4).optional(),
	expiryMonth: z.number().int().min(1).max(12).optional(),
	expiryYear: z.number().int().min(2024).optional(),
	cardHolder: optionalTextSchema,
	isDefault: z.boolean().optional(),
});

const storePaymentFieldsSchema = z
	.array(productAdditionalFieldSchema)
	.max(30)
	.refine(
		fields => new Set(fields.map(field => field.id)).size === fields.length,
		'Campos duplicados'
	);

export const createStorePaymentMethodSchema = z.object({
	storeId: cuidSchema,
	name: z.string().trim().min(1).max(80),
	type: z.enum(PaymentType).optional().default(PaymentType.CUSTOM),
	fields: storePaymentFieldsSchema.default([]),
	isActive: z.boolean().optional().default(true),
});

export const updateStorePaymentMethodSchema = z
	.object({
		name: createStorePaymentMethodSchema.shape.name.optional(),
		type: z.enum(PaymentType).optional(),
		fields: storePaymentFieldsSchema.optional(),
		isActive: z.boolean().optional(),
	})
	.refine(paymentMethod => Object.keys(paymentMethod).length > 0, {
		message: 'at least one field is required',
	});

export const createClientOrderSchema = z.object({
	scheduledAt: z.string().datetime({ offset: true }).optional(),
	paymentFieldValues: z.array(productAdditionalFieldValueSchema).max(30).optional(),
	addressId: cuidSchema.nullable().optional(),
	paymentMethodId: cuidSchema.optional(),
	storePaymentMethodId: cuidSchema.optional(),
	paymentType: z.enum(PaymentType),
	promotionId: cuidSchema.nullable().optional(),
	storeId: cuidSchema,
	items: z.array(createOrderItemSchema).min(1),
	notes: optionalTextSchema,
});

export const listClientOrdersQuerySchema = z.object({
	status: z.union([z.enum(OrderStatus), z.literal('ALL')]).optional(),
	storeId: z.union([cuidSchema, z.literal('ALL')]).optional(),
});

export const createPromotionSchema = z
	.object({
		name: z.string().trim().min(1),
		description: optionalTextSchema.nullable(),
		type: z.enum(PromotionType),
		value: z.number().nonnegative(),
		minPurchase: moneySchema.nullable().optional(),
		maxDiscount: moneySchema.nullable().optional(),
		startDate: z.coerce.date(),
		endDate: z.coerce.date(),
		eligibilityType: z
			.enum(PromotionEligibilityType)
			.optional()
			.default(PromotionEligibilityType.ALL),
		eligibilityTarget: z
			.union([cuidSchema, z.array(cuidSchema)])
			.nullable()
			.optional(),
		usageMode: z
			.enum(PromotionUsageMode)
			.optional()
			.default(PromotionUsageMode.AVAILABLE_PERIOD),
		usageLimit: z.number().int().nonnegative().nullable().optional(),
		isActive: z.boolean().optional(),
		buyProductId: cuidSchema.optional(),
		rewardProductId: cuidSchema.optional(),
		productIds: z.array(cuidSchema).optional(),
		storeIds: storeIdsSchema,
	})
	.superRefine((promotion, context) => {
		if (promotion.endDate <= promotion.startDate) {
			context.addIssue({
				code: 'custom',
				message: 'endDate must be after startDate',
				path: ['endDate'],
			});
		}

		if (
			promotion.isActive !== false &&
			promotion.usageMode === PromotionUsageMode.AVAILABLE_PERIOD
		) {
			const today = new Date();
			today.setHours(0, 0, 0, 0);
			const endDate = new Date(promotion.endDate);
			endDate.setHours(0, 0, 0, 0);

			if (endDate < today) {
				context.addIssue({
					code: 'custom',
					message: 'endDate must be today or later for active available period coupons',
					path: ['endDate'],
				});
			}
		}

		if (promotion.eligibilityType === PromotionEligibilityType.ALL) {
			if (promotion.eligibilityTarget !== null && promotion.eligibilityTarget !== undefined) {
				context.addIssue({
					code: 'custom',
					message: 'eligibilityTarget must be null for all users',
					path: ['eligibilityTarget'],
				});
			}
		}

		if (promotion.eligibilityType === PromotionEligibilityType.GROUP) {
			if (
				!Array.isArray(promotion.eligibilityTarget) ||
				promotion.eligibilityTarget.length === 0
			) {
				context.addIssue({
					code: 'custom',
					message: 'eligibilityTarget must include at least one user group id',
					path: ['eligibilityTarget'],
				});
			}
		}

		if (promotion.eligibilityType === PromotionEligibilityType.SINGLE_USER) {
			if (typeof promotion.eligibilityTarget !== 'string') {
				context.addIssue({
					code: 'custom',
					message: 'eligibilityTarget must be a user id',
					path: ['eligibilityTarget'],
				});
			}
		}

		if (
			promotion.usageMode === PromotionUsageMode.USAGE_QUANTITY &&
			(!promotion.usageLimit || promotion.usageLimit <= 0)
		) {
			context.addIssue({
				code: 'custom',
				message: 'usageLimit must be positive for usage quantity coupons',
				path: ['usageLimit'],
			});
		}

		if (promotion.type === PromotionType.BUY_X_GET_Y) {
			if (!promotion.buyProductId) {
				context.addIssue({
					code: 'custom',
					message: 'buyProductId is required',
					path: ['buyProductId'],
				});
			}

			if (!promotion.rewardProductId) {
				context.addIssue({
					code: 'custom',
					message: 'rewardProductId is required',
					path: ['rewardProductId'],
				});
			}

			return;
		}

		if (promotion.type === PromotionType.PERCENTAGE && promotion.value > 100) {
			context.addIssue({
				code: 'custom',
				message: 'percentage value must be at most 100',
				path: ['value'],
			});
		}

		if (promotion.value <= 0) {
			context.addIssue({
				code: 'custom',
				message: 'value must be positive',
				path: ['value'],
			});
		}
	});

export const applyPromotionCouponSchema = z.object({
	code: z.string().trim().min(1),
	storeId: cuidSchema,
	subtotal: moneySchema,
});

const userGroupRuleValueSchema = z.union([z.string(), z.number().finite(), z.boolean()]);
const userGroupRuleCommonShape = {
	logicalOperator: z.enum(UserGroupLogicalOperator).optional(),
	operator: z.enum(UserGroupRuleOperator),
	value: userGroupRuleValueSchema,
};

export const userGroupRuleSchema = z.discriminatedUnion('source', [
	z.object({
		...userGroupRuleCommonShape,
		field: z.enum(userGroupUserRuleFields),
		source: z.literal(UserGroupRuleSource.USER),
	}),
	z.object({
		...userGroupRuleCommonShape,
		field: z.enum(userGroupOrderRuleFields),
		source: z.literal(UserGroupRuleSource.ORDER),
	}),
	z.object({
		...userGroupRuleCommonShape,
		field: z.enum(userGroupItemRuleFields),
		source: z.literal(UserGroupRuleSource.ITEM),
	}),
	z.object({
		...userGroupRuleCommonShape,
		field: z.literal('preset'),
		operator: z.literal(UserGroupRuleOperator.EQUAL),
		source: z.literal(UserGroupRuleSource.PRESET),
		value: z.enum(UserGroupRulePreset),
	}),
]);

export const userGroupRulesSchema = z
	.array(userGroupRuleSchema)
	.min(1)
	.superRefine((rules, context) => {
		if (rules[0]?.logicalOperator !== undefined) {
			context.addIssue({
				code: 'custom',
				message: 'the first rule cannot have a logical operator',
				path: [0, 'logicalOperator'],
			});
		}

		rules.slice(1).forEach((rule, index) => {
			if (!rule.logicalOperator) {
				context.addIssue({
					code: 'custom',
					message: 'logicalOperator is required after the first rule',
					path: [index + 1, 'logicalOperator'],
				});
			}
		});
	});

const userGroupPayloadShape = {
	mode: z.enum(UserGroupMode).optional().default(UserGroupMode.MANUAL),
	name: z.string().trim().min(1),
	rules: z.array(userGroupRuleSchema).optional().default([]),
	userIds: z.array(cuidSchema).optional().default([]),
};

export const createUserGroupSchema = z
	.object(userGroupPayloadShape)
	.superRefine((group, context) => {
		if (group.mode === UserGroupMode.RULE && group.rules.length === 0) {
			context.addIssue({
				code: 'custom',
				message: 'rule groups must include at least one rule',
				path: ['rules'],
			});
		}
	});

export const updateUserGroupSchema = z.object({
	mode: z.enum(UserGroupMode).optional(),
	name: z.string().trim().min(1).optional(),
	rules: z.array(userGroupRuleSchema).optional(),
	userIds: z.array(cuidSchema).optional(),
});

export const searchUserGroupUsersSchema = z.object({
	rules: userGroupRulesSchema,
});

export const updateSystemSettingsSchema = z.object({
	storeName: optionalTextSchema,
	storeOpen: z.boolean().optional(),
	autoApproveOrders: z.boolean().optional(),
	minOrderValue: moneySchema.optional(),
	freeDeliveryMin: moneySchema.optional(),
	pointsEnabled: z.boolean().optional(),
	pointsPerReal: z.number().int().positive().optional(),
});

export const createStoreShippingSchema = z.object({
	storeId: cuidSchema,
	name: z.string().trim().min(1),
	value: moneySchema,
	shippingTime: z.number().int().nonnegative(),
	isActive: z.boolean().optional(),
});

export const updateDefaultShippingSchema = z.object({
	storeId: cuidSchema,
	value: moneySchema,
	shippingTime: z.number().int().nonnegative(),
});

export const upsertNeighborhoodShippingSchema = z
	.object({
		storeId: cuidSchema,
		neighborhood: z.string().trim().min(1),
		areaId: z.string().uuid().optional(),
		isBlocked: z.boolean().optional().default(false),
		mode: z.enum(ShippingChargeMode),
		shippingId: cuidSchema.nullable().optional(),
		value: moneySchema.nullable().optional(),
		shippingTime: z.number().int().nonnegative().nullable().optional(),
		createTemplate: z.boolean().optional(),
		templateName: optionalTextSchema.nullable(),
	})
	.superRefine((input, context) => {
		if (input.mode === ShippingChargeMode.TEMPLATE && !input.shippingId) {
			context.addIssue({
				code: 'custom',
				message: 'shippingId is required when mode is TEMPLATE',
				path: ['shippingId'],
			});
		}

		if (input.mode === ShippingChargeMode.MANUAL) {
			if (typeof input.value !== 'number') {
				context.addIssue({
					code: 'custom',
					message: 'value is required when mode is MANUAL',
					path: ['value'],
				});
			}

			if (typeof input.shippingTime !== 'number') {
				context.addIssue({
					code: 'custom',
					message: 'shippingTime is required when mode is MANUAL',
					path: ['shippingTime'],
				});
			}
		}
	});

export const createCupPollGuessSchema = z.object({
	brScore: z.number().int().min(0).max(99),
	instagramHandle: z
		.string()
		.trim()
		.regex(/^@[A-Za-z0-9._-]{1,30}$/, 'instagramHandle must start with @'),
	noScore: z.number().int().min(0).max(99),
});

export const getCupPollGuessQuerySchema = z.object({
	instagramHandle: z
		.string()
		.trim()
		.regex(/^@[A-Za-z0-9._-]{1,30}$/, 'instagramHandle must start with @'),
});

const cupPollWinnerOverrideSchema = z
	.string()
	.trim()
	.regex(/^@[A-Za-z0-9._-]{1,30}$/, 'winner must start with @')
	.nullable()
	.optional();

export const createCupPollMatchWinnerSchema = z
	.object({
		'first-winner': cupPollWinnerOverrideSchema,
		match: z
			.string()
			.trim()
			.regex(/^br-[a-z]{2}$/, 'match must use br-xx format'),
		result: z
			.string()
			.trim()
			.regex(/^br\([0-9]+\)-[a-z]{2}\([0-9]+\)$/, 'result must use br(y1)-xx(y2) format'),
		'second-winner': cupPollWinnerOverrideSchema,
	})
	.superRefine((input, context) => {
		const awayTeam = input.match.split('-')[1];
		const resultMatch = input.result.match(/^br\([0-9]+\)-([a-z]{2})\([0-9]+\)$/);

		if (resultMatch?.[1] !== awayTeam) {
			context.addIssue({
				code: 'custom',
				message: 'result away team must match match away team',
				path: ['result'],
			});
		}
	});

// ============================================================================
// DTO TYPES INFERRED FROM ZOD
// ============================================================================

export type RegisterUserDTO = z.infer<typeof registerUserSchema>;
export type SendWhatsAppTextDTO = z.infer<typeof sendWhatsAppTextSchema>;
export type CreateWhatsAppMessageConfigurationDTO = z.infer<
	typeof createWhatsAppMessageConfigurationSchema
>;
export type UpdateWhatsAppMessageConfigurationDTO = z.infer<
	typeof updateWhatsAppMessageConfigurationSchema
>;
export type CreatePrinterConfigurationDTO = z.infer<typeof createPrinterConfigurationSchema>;
export type UpdatePrinterConfigurationDTO = z.infer<typeof updatePrinterConfigurationSchema>;
export type SetPrinterAssignmentsDTO = z.infer<typeof setPrinterAssignmentsSchema>;
export type LoginUserDTO = z.infer<typeof loginUserSchema>;
export type CreateUserDTO = z.infer<typeof createUserSchema>;
export type UpdateUserDTO = z.infer<typeof updateUserSchema>;
export type AddressDTO = z.infer<typeof createAddressSchema>;
export type UpdateAddressDTO = z.infer<typeof updateAddressSchema>;
export type StoreDTO = z.infer<typeof createStoreSchema>;
export type UpdateStoreDTO = z.infer<typeof updateStoreSchema>;
export type StoreBusinessHourDTO = z.infer<typeof createStoreBusinessHourSchema>;
export type CategoryDTO = z.infer<typeof createCategorySchema>;
export type UpdateCategoryDTO = z.infer<typeof updateCategorySchema>;
export type MenuDTO = z.infer<typeof createMenuSchema>;
export type UpdateMenuDTO = z.infer<typeof updateMenuSchema>;
export type SubcategoryDTO = z.infer<typeof createSubcategorySchema>;
export type UpdateSubcategoryDTO = z.infer<typeof updateSubcategorySchema>;
export type ProductDTO = z.infer<typeof createProductSchema>;
export type UpdateProductDTO = z.infer<typeof updateProductSchema>;
export type CreateBadgeDTO = z.infer<typeof createBadgeSchema>;
export type UpdateBadgeDTO = z.infer<typeof updateBadgeSchema>;
export type SetBadgeProductsDTO = z.infer<typeof setBadgeProductsSchema>;
export type CarouselSlideDTO = z.infer<typeof carouselSlideSchema>;
export type CarouselContentDTO = z.infer<typeof carouselContentSchema>;
export type CreateCarouselDTO = z.infer<typeof createCarouselSchema>;
export type UpdateCarouselDTO = z.infer<typeof updateCarouselSchema>;
export type ProductAdditionalFieldDTO = z.infer<typeof productAdditionalFieldSchema>;
export type EffectiveProductAdditionalFieldDTO = z.infer<
	typeof effectiveProductAdditionalFieldSchema
>;
export type ProductAdditionalFieldValueDTO = z.infer<typeof productAdditionalFieldValueSchema>;
export type CartItem = z.infer<typeof cartItemSchema>;
export type Cart = z.infer<typeof cartSchema>;
export type CreateOrderDTO = z.infer<typeof createOrderSchema>;
export type UpdateOrderStatusDTO = z.infer<typeof updateOrderStatusSchema>;
export type ListAdminOrdersQueryDTO = z.infer<typeof listAdminOrdersQuerySchema>;
export type ListClientOrdersQueryDTO = z.infer<typeof listClientOrdersQuerySchema>;
export type UpdateAdminOrderStatusDTO = z.infer<typeof updateAdminOrderStatusSchema>;
export type CreatePaymentMethodDTO = z.infer<typeof createPaymentMethodSchema>;
export type UpdateClientProfileDTO = z.infer<typeof updateClientProfileSchema>;
export type ClientAddressDTO = z.infer<typeof createClientAddressSchema>;
export type UpdateClientAddressDTO = z.infer<typeof updateClientAddressSchema>;
export type ClientPaymentMethodDTO = z.infer<typeof createClientPaymentMethodSchema>;
export type CreateStorePaymentMethodDTO = z.infer<typeof createStorePaymentMethodSchema>;
export type UpdateStorePaymentMethodDTO = z.infer<typeof updateStorePaymentMethodSchema>;
export type ClientOrderDTO = z.infer<typeof createClientOrderSchema>;
export type PromotionDTO = z.infer<typeof createPromotionSchema>;
export type ApplyPromotionCouponDTO = z.infer<typeof applyPromotionCouponSchema>;
export type UserGroupDTO = z.infer<typeof createUserGroupSchema>;
export type UpdateUserGroupDTO = z.infer<typeof updateUserGroupSchema>;
export type UserGroupRuleDTO = z.infer<typeof userGroupRuleSchema>;
export type SearchUserGroupUsersDTO = z.infer<typeof searchUserGroupUsersSchema>;
export type UpdateSystemSettingsDTO = z.infer<typeof updateSystemSettingsSchema>;
export type CreateStoreShippingDTO = z.infer<typeof createStoreShippingSchema>;
export type UpdateDefaultShippingDTO = z.infer<typeof updateDefaultShippingSchema>;
export type UpsertNeighborhoodShippingDTO = z.infer<typeof upsertNeighborhoodShippingSchema>;
export type CreateCupPollGuessDTO = z.infer<typeof createCupPollGuessSchema>;
export type GetCupPollGuessQueryDTO = z.infer<typeof getCupPollGuessQuerySchema>;
export type CreateCupPollMatchWinnerDTO = z.infer<typeof createCupPollMatchWinnerSchema>;

// ============================================================================
// ENTITY TYPES
// ============================================================================

export interface User {
	cpf?: string | null;
	id: string;
	email: string;
	name: string;
	gender?: UserGender | null;
	phone?: string;
	avatar?: string;
	role: UserRole;
	isActive: boolean;
	emailVerified: boolean;
	stores?: StoreSummary[];
	createdAt: Date;
	updatedAt: Date;
}

export interface UserWithSensitive extends User {
	password?: string;
}

export interface Address extends AddressDTO {
	id: string;
	userId: string;
	isDefault: boolean;
	zipCodeValidated: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface StoreSummary {
	id: string;
	name: string;
	nickname: string;
	isActive: boolean;
	isClosed?: boolean;
	layout?: SystemLayout;
	address?: StoreSummaryAddress;
}

export interface StoreSummaryAddress {
	city: string;
	cityCode?: string | null;
	complement?: string | null;
	id: string;
	latitude?: number | null;
	longitude?: number | null;
	neighborhood: string;
	number: string;
	state: string;
	street: string;
	zipCode: string;
}

export interface StoreBusinessHour {
	id: string;
	storeId: string;
	weekDay?: number | null;
	date?: Date | null;
	openTime?: Date | null;
	closeTime?: Date | null;
	isClosed: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface Store extends Omit<StoreDTO, 'businessHours'> {
	id: string;
	isActive: boolean;
	isClosed?: boolean;
	address?: Address;
	owner?: User;
	businessHours?: StoreBusinessHour[];
	createdAt: Date;
	updatedAt: Date;
}

export interface Category extends Omit<CategoryDTO, 'storeIds'> {
	id: string;
	stores?: StoreSummary[];
	order: number;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface Subcategory extends Omit<SubcategoryDTO, 'categoryId' | 'storeIds'> {
	id: string;
	categoryId: string;
	category?: Category;
	stores?: StoreSummary[];
	order: number;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface Menu extends Omit<MenuDTO, 'categoryIds' | 'storeIds' | 'subcategoryIds'> {
	id: string;
	categories: Category[];
	subcategories: Subcategory[];
	stores?: StoreSummary[];
	order: number;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface Badge {
	id: string;
	color: string;
	icon?: string | null;
	isActive: boolean;
	name: string;
	storeId: string;
	createdAt: Date;
	updatedAt: Date;
}

export interface Product extends Omit<ProductDTO, 'badgeIds' | 'storeIds'> {
	id: string;
	badges?: Badge[];
	stores?: StoreSummary[];
	order: number;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface OrderItem {
	id: string;
	orderId: string;
	productId: string;
	price: number;
	quantity: number;
	notes?: string;
}

export interface Order {
 scheduledAt?: Date | null;
	id: string;
	userId?: string;
	addressId?: string | null;
	address?: Address;
	storeId: string;
	store?: StoreSummary;
	paymentMethodId?: string;
	promotionId?: string | null;
	status: OrderStatus;
	items: OrderItem[];
	subtotal: number;
	deliveryFee: number;
	discount: number;
	total: number;
	notes?: string;
	estimatedDelivery?: Date;
	deliveredAt?: Date;
	createdAt: Date;
	updatedAt: Date;
}

export interface AdminOrderCustomer {
	id: string;
	email: string;
	name: string;
	phone?: string | null;
}

export interface AdminOrderProductSummary {
	category?: { name: string } | null;
	subcategory?: { name: string } | null;
	id: string;
	name: string;
	imageUrl?: string | null;
	categoryId: string;
	subcategoryId?: string | null;
}

export interface AdminOrderAddress {
	id: string;
	userId: string;
	street: string;
	number: string;
	complement?: string | null;
	neighborhood: string;
	city: string;
	state: string;
	zipCode: string;
	latitude?: number | null;
	longitude?: number | null;
	isDefault: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface AdminOrderPaymentMethod {
	id: string;
	type: PaymentType;
	cardType?: PaymentCardType | null;
	provider: string;
	last4?: string | null;
	cardHolder?: string | null;
}

export interface AdminOrderItem {
	additionalFieldValues?: ProductAdditionalFieldValueDTO[] | null;
	id: string;
	orderId: string;
	productId: string;
	product: AdminOrderProductSummary;
	price: number;
	quantity: number;
	notes?: string | null;
}

export interface AdminOrder {
 scheduledAt?: Date | null;
	confirmedAt?: Date | null;
	deliveryMinutes?: number | null;
	paymentAdditionalValue?: number;
	paymentFieldValues?: unknown;
	orderNumber?: number;
	id: string;
	userId?: string | null;
	user?: AdminOrderCustomer | null;
	addressId?: string | null;
	address?: AdminOrderAddress | null;
	storeId?: string | null;
	store?: StoreSummary | null;
	paymentType?: PaymentType | null;
	paymentMethodId?: string | null;
	paymentMethod?: AdminOrderPaymentMethod | null;
	storePaymentMethodId?: string | null;
	storePaymentMethod?: StorePaymentMethod | null;
	promotionId?: string | null;
	status: OrderStatus;
	items: AdminOrderItem[];
	subtotal: number;
	deliveryFee: number;
	discount: number;
	total: number;
	notes?: string | null;
	estimatedDelivery?: Date | null;
	deliveredAt?: Date | null;
	createdAt: Date;
	updatedAt: Date;
}

export interface WhatsAppMessageConfiguration {
	id: string;
	location: WhatsAppMessageLocation;
	operation: WhatsAppMessageOperation;
	paymentMethodId?: string | null;
	paymentMethod?: StorePaymentMethod | null;
	template: WhatsAppMessageTemplateDTO;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface PrinterConfiguration extends PrinterOperationalConfiguration {
	receiptLayout?: PrinterReceiptLayout | null;
	receiptSections?: PrinterReceiptSection[];
	id: string;
	storeId: string;
	connectionId: string;
	name: string;
	connectionStatus: PrinterConnectionStatus;
	isPrimary: boolean;
	categoryIds: string[];
	subcategoryIds: string[];
	createdAt: Date;
	updatedAt: Date;
}

export interface PaymentMethod extends CreatePaymentMethodDTO {
	id: string;
	cardType?: PaymentCardType | null;
	isDefault: boolean;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface StorePaymentMethod {
	fields?: ProductAdditionalFieldDTO[];
	id: string;
	storeId: string;
	name: string;
	type: PaymentType;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface Payment {
	id: string;
	orderId: string;
	paymentMethodId: string;
	amount: number;
	status: PaymentStatus;
	provider: string;
	providerTxId?: string;
	providerResponse?: Record<string, unknown>;
	paidAt?: Date;
	createdAt: Date;
	updatedAt: Date;
}

export interface Promotion extends Omit<PromotionDTO, 'productIds' | 'storeIds'> {
	id: string;
	isActive: boolean;
	products?: Product[];
	stores?: StoreSummary[];
	createdAt: Date;
	updatedAt: Date;
}

export interface UserGroup {
	id: string;
	mode: UserGroupMode;
	name: string;
	rules: UserGroupRuleDTO[];
	members: User[];
	createdAt: Date;
	updatedAt: Date;
}

export interface SystemSettings {
	id: string;
	storeName: string;
	storeOpen: boolean;
	autoApproveOrders: boolean;
	minOrderValue: number;
	freeDeliveryMin?: number;
	pointsEnabled: boolean;
	pointsPerReal: number;
	createdAt: Date;
	updatedAt: Date;
}

export interface DeliveryZone {
	id: string;
	name: string;
	neighborhood: string;
	city: string;
	state: string;
	zipCode?: string;
	fee: number;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface StoreShipping {
	id: string;
	storeId: string;
	name: string;
	value: number;
	shippingTime: number;
	createdAt: Date;
	isActive: boolean;
}

export interface StoreNeighborhoodShipping {
	id: string;
	storeId: string;
	neighborhood: string;
	isBlocked: boolean;
	mode: ShippingChargeMode;
	shippingId?: string | null;
	shipping?: StoreShipping | null;
	value?: number | null;
	shippingTime?: number | null;
	createdAt: Date;
	updatedAt: Date;
}

export interface Notification {
	id: string;
	userId: string;
	type: NotificationType;
	title: string;
	message: string;
	isRead: boolean;
	createdAt: Date;
}

export interface Review {
	id: string;
	userId: string;
	productId: string;
	rating: number;
	comment?: string;
	isActive: boolean;
	createdAt: Date;
	updatedAt: Date;
}

export interface ReviewDTO {
	productId: string;
	rating: number;
	comment?: string;
}

export interface Favorite {
	id: string;
	userId: string;
	productId: string;
	createdAt: Date;
}

export interface Point {
	id: string;
	userId: string;
	amount: number;
	type: PointType;
	description?: string;
	orderId?: string;
	createdAt: Date;
}

export interface UserPoints {
	userId: string;
	balance: number;
	totalEarned: number;
	totalRedeemed: number;
}

export interface CupPollGuess {
	id: string;
	instagramHandle: string;
	score: string;
	createdAt: Date;
}

// ============================================================================
// API RESPONSE TYPES AND HELPERS
// ============================================================================

export interface ApiResponse<T = unknown> {
	success: boolean;
	data?: T;
	error?: string;
	message?: string;
}

export interface PaginatedResponse<T> {
	data: T[];
	pagination: {
		page: number;
		limit: number;
		total: number;
		totalPages: number;
	};
}

export interface ApiError {
	message: string;
	code?: string;
	statusCode?: number;
	details?: Record<string, unknown>;
}

export interface JwtPayload {
	userId: string;
	email: string;
	role: UserRole;
	iat?: number;
	exp?: number;
}

export interface AuthResponse {
	user: User;
	token: string;
	refreshToken?: string;
}

export function formatZodError(error: z.ZodError): ApiError {
	return {
		message: 'Validation error',
		code: 'VALIDATION_ERROR',
		statusCode: 400,
		details: error.flatten() as unknown as Record<string, unknown>,
	};
}

export function safeParseApiInput<TSchema extends z.ZodType>(
	schema: TSchema,
	input: unknown
): ApiResponse<z.infer<TSchema>> {
	const result = schema.safeParse(input);

	if (!result.success) {
		const error = formatZodError(result.error);

		return {
			success: false,
			error: error.message,
			data: undefined,
			message: error.code,
		};
	}

	return {
		success: true,
		data: result.data,
	};
}

export * from './delivery-geometry.js';

export * from './additional-field-selection.js';

export * from './store-operation.js';
